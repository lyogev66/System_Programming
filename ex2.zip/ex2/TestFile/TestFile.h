/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
/* 
Author= Ziv Belahsan 201567278 Yogev laks=200344729
Project=Exercise 2
Using -				 
	
Description -	The thead function header file
*/
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
#ifndef TEST_FILE_H
#define TEST_FILE_H

#include <stdio.h>
#include <Windows.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "StringConversionTools.h"

#define MY_ERROR				0
#define STATUS_OK				1
#define THREAD_NUMBER			4
#define	SIZE_QUANT				1024
#define NumberOfBytesToRead		5
#define ALL_THREAD_FINNISHED	15
#define NUMBER_OF_ARGUMENTS		3
#define NO_TOKEN_FOUND			0x15
#define SLEEP_TIME				10
#define END_CHARACTER			1


/*A stract to deliver the tread that runs test_get_times function */
typedef struct
{
	FILETIME	CreationTime;
	FILETIME	lastmodified;
	SYSTEMTIME	UTC_lastmodified;
	SYSTEMTIME	UTC_CreationTime;
	SYSTEMTIME	UTC_Isreal_lastmodified;
	SYSTEMTIME	UTC_Israel_CreationTime;
}FILE_TIMES;

/*A stract to deliver the tread that runs test_file_extension function */
typedef struct
{
	char *file_extention;
	char *file_name;
	char *First_five_chars;
}FILE_STRINGS;

/*ENUM- used to indicated the file size*/
typedef enum FILE_UNITS
{
	B,
	KB,
	MB,
	GB,
	TB,
}FILE_UNITS;

/*A stract to deliver the tread that runs test_file_size function */
typedef struct
{
	double file_size;
	FILE_UNITS units;
}SIZE_INFORMATION;

/*ENUM- used to indicated the thread name*/
typedef enum
{
	TIME_THREAD,
	SIZE_FILE_THREAD,
	FIRST_5_CHARS_THREAD,
	EXTENTION_FILE_THREAD
}THREAD_ID;


//#pragma pack(1)
/*This insrtuctions providing additional information to the compiler.*/
/*In this case we ask nicely the compiler - please do not pad with zeroes the next structs or arguments*/
/*We do so so we could check later which or how many threads has finnished running, How we do so?, let us explain:*/
/*For each thread the is signaled (AKA finnished), we update the struct below, at the correct field, to 1*/
/*This struct is a BIT-FIELD struct, meaning - we tell the compiler how many bits we want it to spare for each field*/
/*Here below we ask only for 1 BIT for each field - to indicate '1'- Finnished or '0' - Still running*/
/*By doing it we :	A) save memory place, there isnt a need for min 8 bits to indicate just '1' or '0' */
/*					B) becouse of the pragma instruction those bits will sit sequentially at the memory*/
/*Reading later this bits (by methode we will explain below) we can tell which or how many threads has finnished*/
/*The question asked HOW do you read those bits? - please go down to our next comment below*/
typedef struct {
	char TIME_THREAD_STATUS				:1;
	char SIZE_FILE_THREAD_STATUS		:1;
	char FIRST_5_CHARS_THREAD_STATUS	:1;
	char EXTENTION_FILE_THREAD_STATUS	:1;
} THREAD_STATUS;

/*So, how do we read those bits?*/
/*we use special structure called UNION*/
/*in UNION the fields are sharing the same memory space - meaning they will contain the same data*/
/*Each field has it's type. They do not have to be the same.*/
/*Our union containes a field of the type of the struct above which is a BIT-FIELD struct and a field of type CHAR*/
/*Since the fields share the same memory space AND we pre-asked the compiler to not pad with zeroes the BIT-FIELD struct fields*/
/*We can read the CHAR field and recive the char expression that describe those sequent bits of the BIT-FIELD struct*/
/*Foe example, Let say that all the threads has finnished running-> all the fields of the BIT-FIELD struct will be '1'*/
/*At the memory they will be save as sequnce of bits = '1111' */
/*Interperting thos bits as a CHAR,the char value will be '00001111' = 15*/
typedef union STATUS_DATA
{
	THREAD_STATUS ts;
	char c_ts;
}STATUS_DATA;

/*If you find our methode unique and Surprisingly FUN feel free the share some extra points $$$$$ */


#endif