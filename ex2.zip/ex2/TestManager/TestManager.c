/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
/* 
Author= Ziv Belahsan 201567278 Yogev laks=200344729
Project=Exercise 2
Using -			TestManager.h	 
	
Description -	runs the managing files and initates TestMangager project
*/
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
#include "TestManager.h"

/*#define CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define MemoryLeak*/

/*HERE we declare global list arguments heads */
/*g_Live_process_head - List of STILL_ACTIVE proccesses*/
/*g_Dead_process_head - List of finnished proccesses*/

Process_list *g_Live_process_head = NULL;
Process_list *g_Dead_process_head = NULL;
int g_Processcount = 0;

/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
function name :		Create_Process_Argument
Input arguments:	char *target_process_name - the string "TestFile.exe"
					char *file_name - the name of the current file
					char *output_directory_name - the full path

return:				char* - the compleate command line for TestFile.

Description-		The function creates an arument line which will be used to initate the process.
oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
char* Create_Process_Argument(char *target_process_name,char *file_name,char *output_directory_name)
{
	char *argument_command = NULL, *ShortFileName = NULL, *file_name_copy = NULL;
	int ret=0;
	file_name_copy = (char*) calloc (strlen(file_name) +EOF_CHARACTER,CHARACTER_SIZE);
	if(file_name_copy == NULL)
	{
		printf("Allocation failed\n");
		exit(ERROR_CODE);
	}
	strcpy(file_name_copy,file_name);
	ShortFileName = strtok(file_name_copy,".");
	argument_command = (char*) calloc(strlen(target_process_name) + strlen(file_name) + strlen (ShortFileName) + strlen(output_directory_name) + strlen("_log.txt") + strlen ("\\") + 7*EOF_CHARACTER, CHARACTER_SIZE);
	if(argument_command == NULL)
	{
		printf("ERROR at argument_command \n");
		exit(ERROR_CODE);
	}
	ret = sprintf(argument_command,"%s \"%s\" \"%s\\%s_log.txt\"",target_process_name,file_name,output_directory_name,ShortFileName);
	if (ret < 0)
		goto FAIL;
	return argument_command;

FAIL:
	printf("Create_Process_Argument failed\n");
	free(argument_command);
	exit(ERROR_CODE);
}
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
function name :		create_output_folder_arguments
Input arguments:	char *path - the path from argv
					int flag - indicates which action needs to be done
								CREATE_DIRECTORY_FLAG - creates the string that will be used to create the output directory
								CREATE_FILE_INSIDE_DIRECTORY_PATH - creates the string that will be used later to create log file inside the directory
return:				char* - the representive string according to the flag

Description-		creates a strings that will be used as arguments to create new folder or a file inside the folder.
oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
char* create_output_folder_arguments(char *path,int flag)
{
	char* tmp=NULL, *ret=NULL;
	if(!flag)
	{
		tmp = (char*) calloc(strlen(path) + 3,CHARACTER_SIZE);
		if(tmp == NULL)
			exit(ERROR_CODE);
		strcat(tmp,path);
		return tmp;
	}
	else
	{
		tmp = (char*) calloc (strlen(path)+ strlen("runtime_logfile.txt") + 6,CHARACTER_SIZE);
		strcat(tmp,path);

		strcat(tmp,"\\");
		strcat(tmp,"runtime_logfile.txt");
	}
	return tmp;
}
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
function name :		process_lists_management
Input arguments:	NONE

return:				NONE	

Description-		manages the global dead or alive processes lists
					calls a function that moves a dead process from the alive list to the dead process list
oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
void process_lists_management(void)
{
	Process_list *live_tmp = g_Live_process_head , *dead_tmp = g_Dead_process_head, *tmp=NULL;
	DWORD waitcode;
	while(live_tmp != NULL)
	{
		waitcode = WaitForSingleObject(live_tmp->procinfo.hProcess, 0);

		if(waitcode == WAIT_OBJECT_0) 
		{	
			GetExitCodeProcess(live_tmp->procinfo.hProcess,&(live_tmp->exitcode));
			tmp = pop_node_from_list(g_Live_process_head,live_tmp->procinfo.dwProcessId);
			tmp->next =NULL;
			g_Dead_process_head = push_element(g_Dead_process_head,tmp);
			g_Processcount--;
			if(g_Live_process_head !=NULL)
				live_tmp = g_Live_process_head;	
			else
				break;
		}
		live_tmp = live_tmp->next;
	}
}
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
function name :		InitiateProcess
Input arguments:	LPTSTR CommandLine	- a string of the command line argument to send to the process
					FILE *fp			- a file that will handle the output for the process 
					char* file_name		- a file name to which the process belongs

return:				None

Description-		initiate the process according to CommandLine
oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
void InitiateProcess(char* CommandLine,FILE *fp,char* file_name)
{
	PROCESS_INFORMATION procinfo ;
	STARTUPINFO    startinfo = { sizeof(STARTUPINFO), NULL, 0 }; 
	Process_list *node = NULL;
	LPTSTR CommandLine_LPTSTR;
	printf("%s\n", CommandLine);
	CommandLine_LPTSTR = ConvertCharStringToLPTSTR (CommandLine);
	if(CreateProcess(NULL,		/*  No module name (use command line). */
		CommandLine_LPTSTR,		/*  Command line. */
		NULL,					/*  Process handle not inheritable. */
		NULL,					/*  Thread handle not inheritable. */
		FALSE,					/*  Set handle inheritance to FALSE. */
		NORMAL_PRIORITY_CLASS,	/*  creation/priority flags. */
		NULL,					/*  Use parent's environment block. */
		NULL,					/*  Use parent's starting directory. */
		&startinfo,				/*  Pointer to STARTUPINFO structure. */
		&procinfo				/*  Pointer to PROCESS_INFORMATION structure. */
		))
	{
		//fprintf(fp,"Successfully created a process with ID %d to execute %s\n",procinfo.dwProcessId,file_name);
		fprintf(fp,"Successfully created a process with ID %d to execute %s\n",procinfo.dwProcessId,CommandLine);

		//node = creat_node(procinfo,file_name);
		node = creat_node(procinfo,CommandLine);
		g_Live_process_head = push_element(g_Live_process_head,node);
		g_Processcount++;
	}
	else
	{
		fprintf(fp,"!!! Failed to create new process to run %s. Error code: 0x%x !!!\n",file_name,GetLastError());
		//exit(ERROR_CODE);
	}
}
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
function name :		free_processes
Input arguments:	None

return:				None

Description-		goes over the dead process list and frees the process handles
oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
void free_processes()
{
	Process_list *tmp = g_Dead_process_head;
	while(tmp!=NULL)
	{
		CloseHandle(tmp->procinfo.hProcess);
		CloseHandle(tmp->procinfo.hThread);
		tmp = tmp->next;
	}
}
/*oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO
function name :		main
Input arguments:	int argc	-command line argument count
					char* argv[]-a pointer to command line argument strings

return:				None

Description-		handles the project
oOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoOoO*/
int main(int argc,char* argv[])
{
	/*Declerations of variables*/
	char ch ,BOOL= TRUE;
	FILE *instream = NULL , *outstream = NULL;
	char *file_name = NULL,*output_directory_name = NULL,target_process_name[] =TARGET_NAME;
	char *complete_arguments_command = NULL,*output_dir = NULL;
	int length=0;
	LPTSTR CreateDirectory_LPTSTR;
	/*End declerations*/

	/*Check Input number of arguments*/
	if(argc != CORRECT_ARGUMEN_NUMVER)
	{
		printf("Incorrect number of arguments\n");
		exit(ERROR_CODE);
	}
	/*START - Creating output folder for the log file*/
	output_directory_name = (char*) malloc(strlen(argv[2]) + CHARACTER_SIZE);
	if(output_directory_name == NULL)
	{
		printf("Allocation failed\n");
		exit(ERROR_CODE);
	}
	strcpy(output_directory_name,argv[2]);
	output_dir = create_output_folder_arguments(argv[2],CREATE_DIRECTORY_FLAG);
	CreateDirectory_LPTSTR = ConvertCharStringToLPTSTR(output_dir);

	if(!CreateDirectory(CreateDirectory_LPTSTR,NULL))
	{
		printf("%s %s \n",argv[2], GetLastError()==ERROR_ALREADY_EXISTS? "ERROR_ALREADY_EXISTS":"ERROR_PATH_NOT_FOUND");
		if(GetLastError()!=ERROR_ALREADY_EXISTS)
			exit(ERROR_CODE);
	}
	free(output_dir);
	output_dir = NULL;
	/*END - creating output folder*/

	/*START - Creating runtime_log_file.txt inside the output folder with permitions of writing and reading*/
	output_dir = create_output_folder_arguments(argv[2],CREATE_FILE_INSIDE_DIRECTORY_PATH);
	if(fopen_s(&outstream,output_dir,"w")!= OK)
		exit(0);
	/*END - Creating runtime_log_file.txt */

	/*Opening the input file for reading*/
	if(fopen_s(&instream,argv[1],"r") != OK)
	{
		printf("%d\n",GetLastError());
		exit(GetLastError());
	}

	/*Without assuming the file name inside of the input file we allocate a string with 1 byte*/
	file_name = (char*)calloc(CHARACTER_SIZE,CHARACTER_SIZE);
	if(NULL == file_name)
	{
		printf("Error allocating string for file name \n");
		exit(ERROR_CODE);
	}
	while (1)
	{
		/*Inside the while loop we go over the input file and disassemble it to strings*/
		/*Each string is a file name*/
		/*Per each file we create the specific command to initiate with the process*/
		ch = getc(instream);
		if ((ch != '\r') && (ch!='\n') && (ch !='\0') && (ch!=EOF))
		{
			length++;
			file_name = (char*)realloc(file_name, length + CHARACTER_SIZE);
			if(NULL == file_name)
			{
				printf("Error parsing file name \n");
				exit(ERROR_CODE);
			}
			file_name[length - CHARACTER_SIZE] = ch;
		}
		else
		{
			if(0 == length)
			{
				printf("Empty file!\n");
				exit(ERROR_CODE);
			}
			file_name[length] = '\0';
			/*By here we have a string containes the file name*/
			complete_arguments_command = Create_Process_Argument(target_process_name,file_name,output_directory_name);//A function to build the specific command line for this file name

			/*creating a proccess with the instructed command line and inserting the process into Live_process list.*/
			/*A counter g_Processcount increased per each succsessful proccess initiating - indicates the amount of living processes*/
			InitiateProcess(complete_arguments_command,outstream,file_name);


			free(complete_arguments_command);
			length = 0;
			if(EOF == ch)//check if we arrived to the end of file to exit the while loop
			{
				BOOL = FALSE;
				break;
			}
		}
	}

	/*we finnished handeling with the input file parsing and we continue to check repeatedly the initiated proccess liveness*/
	while(g_Processcount)
	{
		/*//This function checks for the liveness of all the living proccess at the live_process's list*/
		/*In case that a proccess has finnished, the function removes it from the live_proccess list into the dead_proccess list, and updates the g_Processcount as well*/
		process_lists_management();

		/*Printing the information about the processes*/
		print_live_process_list(g_Live_process_head,outstream);
		print_dead_process_list(g_Dead_process_head,outstream);

		/*If all the processes at this point has finnished the g_Live_process_head which holded the head of the living processes is NULL, since well - all the processes are finnished running */
		if(g_Live_process_head == NULL)
			goto EXIT_PROGRAM;

		/*Here we maintain the frequent checking*/
		Sleep(atoi(argv[3]));
	}


EXIT_PROGRAM:

	printf("exiting program\n");
	fprintf(outstream,"All the processes have finished running.Exiting program.");
	free_processes();// Free the main Thread and the Proccess handles.
	free_list(g_Live_process_head,"g_Live_process_head");//Free each data maintaned for each live proccess
	free_list(g_Dead_process_head,"g_Dead_process_head");//Free each data maintaned for each dead proccess
	fclose(instream);
	fclose(outstream);
	free((char*)output_directory_name);
	free((char*)output_dir);
	free(file_name);	
//	printf("mem leak %d \n",_CrtDumpMemoryLeaks());  //Call this function to view the unrelease memory
}