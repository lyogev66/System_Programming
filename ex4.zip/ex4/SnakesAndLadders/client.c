#include "client.h"
#include "gamePlay.h"
#include "common.h"


#define DEBUG 1

void printDebug(const char *fmt, ...)
{
	va_list ap;

	if (DEBUG)
	{
		va_start(ap, fmt);
		vfprintf(stdout, fmt, ap);
		va_end(ap);
	}
}

void printToLogAndScreenLocked(ARGUMENTS_S *Args,const char *fmt, ...)
{
	va_list ap;

	printDebug("secure printing\n");
	WaitForSingleObject( Args->writingLock,INFINITE);
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	vfprintf(Args->logFile, fmt, ap);
	va_end(ap);
	ReleaseMutex( Args->writingLock );
}

void fprintfWithLock(ARGUMENTS_S *Args,const char *fmt, ...)
{
	va_list ap;

	WaitForSingleObject(Args->writingLock,INFINITE);

	va_start(ap, fmt);
	vfprintf(Args->logFile, fmt, ap);
	va_end(ap);

	ReleaseMutex(Args->writingLock);
}

void sendAndLog(ARGUMENTS_S *Args,char* stringToSend)
{
	char sendbuffer[MAX_BUFFER_SIZE] = {0};

	sprintf(sendbuffer,"%s\n",stringToSend);

	if(Args->client.winner)
		send(Args->client.clientSocket,sendbuffer,strlen(sendbuffer)+10,0);
	else
		send(Args->client.clientSocket,sendbuffer,strlen(sendbuffer)+1,0);
	fprintfWithLock(Args,"Sent to server:%s\n",stringToSend);
	//ZeroMemory(stringToSend,sizeof(stringToSend));
}

void closeMySocket(SOCKET socket)
{

	if ( closesocket(socket) == SOCKET_ERROR ){
		printf("Error closing client socket %d\n",WSAGetLastError());
		exit(EXIT_ERROR);
	}
	WSACleanup();
}

void parseFromUser(ARGUMENTS_S* Args)
{
	char ch;
	int bufferIndex = 0;

	ch = fgetc(stdin);

	while((ch != '\n') && (ch != EOF) && (ch != '\r'))
	{
		Args->sendBuffer[bufferIndex++] = ch;
		ch = fgetc(stdin);
	}
	Args->sendBuffer[bufferIndex] = '\0';  
}

//get the responce from server
void getConnectionResponce(ARGUMENTS_S* Args)
{
	char buffer[MAX_BUFFER_SIZE] = {0};
	char tempString[PLAYER_NAME_SIZE] = {0};
	int iResult;
	clientStruct *myClient = &(Args->client);

	iResult = recv(myClient->clientSocket,buffer,MAX_BUFFER_SIZE,0);
	if ( iResult > 0 )
	{
		sscanf(buffer,"%s",tempString);

		if(!strcmp(tempString, Args->client.userName))   //is the message is the username, parse the pawn type
		{
			sscanf(buffer,"%s %s %s %s %s %s",tempString,tempString,tempString,tempString,tempString,tempString);
			myClient->pawnType=tempString[0];
		}
		else										//else connection is refused
			printToLogAndScreenLocked(Args,"Connection to server refused. Exiting.\n");
	}
	else
		printf("recv failed with error: %d\n", WSAGetLastError());
}

//connecting to server in the specipied port and logging the username sent to the server
void connectToServer(ARGUMENTS_S *Args,int portNumber)
{
	struct sockaddr_in clientAdd;
	WSADATA wsaData;
	int retval;
	char buffer[MAX_BUFFER_SIZE] = {0};
	FILE *logFile = Args->logFile;

	if ((retval = WSAStartup(0x202, &wsaData)) != 0)
	{
		printf("Client: WSAStartup() failed with error %d\n", retval);
		WSACleanup();
		exit(EXIT_ERROR);
	}

	clientAdd.sin_family = AF_INET;
	clientAdd.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
	clientAdd.sin_port = htons(portNumber);

	Args->client.clientSocket = socket(AF_INET,SOCK_STREAM,0);
	if (Args->client.clientSocket == INVALID_SOCKET)
	{
		WSACleanup();
		exit(EXIT_ERROR);
	}

	if(connect(Args->client.clientSocket,(struct sockaddr*)&clientAdd,sizeof(clientAdd)) != SOCKET_ERROR)
	{	//connect succes
		printToLogAndScreenLocked(Args,"Connected to server on port %d\n",portNumber);
		sprintf(buffer,"username=%s",Args->client.userName);
		sendAndLog(Args,buffer);

	}
	else
	{	//connect fail
		printToLogAndScreenLocked(Args,"Failed connecting to server on port %d\n",portNumber);
		closesocket(Args->client.clientSocket);
		WSACleanup();
		exit (EXIT_ERROR);
	}
	getConnectionResponce(Args);
	printDebug("DEBUG: completed connecting to server\n");

}

void initiateClientThreads(HANDLE *threadsRoutinesArray,LPTHREAD_START_ROUTINE *threadRoutines,ARGUMENTS_S* Args)
{
	int i;
	DWORD threadID = 0;

	for(i = 0; i < NUMBER_OF_THREADS; i++)
	{
		threadsRoutinesArray[i] = CreateThread(NULL,0,threadRoutines[i],Args,0,&threadID);
		CHECK_THREAD_CREATION(threadsRoutinesArray[i]);
	}
}

void initiateClientEvents(HANDLE *eventsArray,ARGUMENTS_S* Args)
{
	int i;

	for(i = 0; i < NUMBER_OF_THREADS; i++)
	{
		eventsArray[i] = CreateEvent(NULL,TRUE,FALSE,NULL);
		CHECK_EVENT_CREATION(eventsArray[i]);
	}
	Args->threadEvents = eventsArray;

	//create Engine Event
	Args->engineWorkingEvent = CreateEvent(NULL,TRUE,TRUE,NULL);	
	CHECK_EVENT_CREATION(Args->engineWorkingEvent);
	printDebug("DEBUG: Created engineWorkingEvent\n");
}

void initiateLocks(ARGUMENTS_S* Args)
{
	Args->msgInProgress = CreateMutex(NULL,FALSE,NULL);
	CHECK_MUTEX_CREATION(Args->msgInProgress);

	Args->writingLock = CreateMutex(NULL,FALSE,NULL);
	CHECK_MUTEX_CREATION(Args->writingLock);

	printDebug("DEBUG: created all mutex\n");

}

void parseMessage(char sendBuffer[MAX_BUFFER_SIZE],char message[MESSAGE_SIZE],char userName[USERNAME_SIZE],E_MESSAGE_TYPE type)
{
	char command[MESSAGE_SIZE] = {0};
	int i = 0,j = 0;
	switch(type)
	{
	case PLAYER_TO_PLAYER_MESSAGE_E:
		{
			sscanf(sendBuffer,"%s %s",command,userName);
			j = strlen(command)+strlen(userName)+2;
			while( sendBuffer[j] != '\0')
			{
				message[i++] = sendBuffer[j++];
			}
			message[i] = '\0';
			break;
		}
	case BROADCAT_MESSAGE_E:
		{
			sscanf(sendBuffer,"%s",command);
			j = strlen(command)+1;
			while(sendBuffer[j] != '\0')
			{
				message[i++] = sendBuffer[j++];
			}
			message[i] = '\0';
			break;
		}
	}
}

int CheckInputMessageValid(ARGUMENTS_S* Args)
{
	char command[MAX_BUFFER_SIZE] = {0};
	char message[MESSAGE_SIZE] = {0};
	char username[USERNAME_SIZE] = {0};
	FILE* logFile = Args->logFile;

	sscanf(Args->sendBuffer,"%s",command);
	if( !strcmp(command,"players") )
	{
		//checing if the arguments are valid arguments
		if(strlen(Args->sendBuffer) == strlen("players"))
			return TRUE;
		else
			printToLogAndScreenLocked(Args,"Illegal argument for command players. Command format is players.\n");
	}
	else if( !strcmp(command,"play"))
	{
		if(strlen(Args->sendBuffer) == strlen("play"))
		{
			return TRUE;
		}
		else
			printToLogAndScreenLocked(Args,"Illegal argument for command play. Command format is play.\n");
	}
	else if( !strcmp(command,"message"))
	{
		parseMessage(Args->sendBuffer,message,username,PLAYER_TO_PLAYER_MESSAGE_E);
		if(strlen(Args->sendBuffer) == (strlen(command)+strlen(username)+strlen(message)+2))
			return TRUE;
		else
			printToLogAndScreenLocked(Args,"Illegal argument for command message. Command format is message <user> <message>.\n");
	}
	else if( !strcmp(command,"broadcast"))
	{             
		parseMessage(Args->sendBuffer,message,username,BROADCAT_MESSAGE_E);
		if( strlen(Args->sendBuffer) == (strlen(command)+strlen(message)+1))
			return TRUE;
		else
			printToLogAndScreenLocked(Args,"Illegal argument for command message. Command format is broadcast <message>.\n");//not ok
	}
	else if(!strcmp(command,"quit"))
	{
		Args->errorOccure=TRUE;
		return QUIT_THREAD;
	}
	else
		printToLogAndScreenLocked(Args,"Command %s is not recognized. Possible commands are: players, message, broadcast and play.\n",command);
	return FALSE;
}

void UIThread(ARGUMENTS_S* Args)
{
	HANDLE threadEvent = Args->threadEvents[SCANF_INDEX];
	HANDLE msgInProgress = Args->msgInProgress;
	HANDLE engineWorkingEvent = Args->engineWorkingEvent;
	char retMsg[MAX_BUFFER_SIZE]={0};
	int inputMessageValid = -1;

	printDebug("DEBUG: starting UIThread\n");
	do
	{
		Sleep(10);
		parseFromUser(Args);

		WaitForSingleObject(msgInProgress,INFINITE);	// engine working
		ResetEvent(engineWorkingEvent);

		inputMessageValid = CheckInputMessageValid(Args);

		if ( inputMessageValid == TRUE ) //if command is valid - engine starts working on it
			SetEvent(threadEvent);

		else if ( inputMessageValid == FALSE ) //else no need for engine to work
			SetEvent(engineWorkingEvent);
		else {							
			SetEvent(engineWorkingEvent);
			ReleaseMutex(msgInProgress);
			ExitThread(QUIT_THREAD);
		}
		WaitForSingleObject(engineWorkingEvent,INFINITE);
		ReleaseMutex(msgInProgress);

	}while(TRUE);
}

void ClientCommunicationThread(ARGUMENTS_S* Args)
{
	HANDLE threadEvent = Args->threadEvents[RECV_INDEX];
	HANDLE engineWorkingEvent = Args->engineWorkingEvent;
	HANDLE msgInProgress = Args->msgInProgress;
	Sleep(10);
	printDebug("DEBUG: starting ClientCommunicationThread\n");
	do{
		memset(Args->recvBuffer,0,sizeof(Args->recvBuffer));
		Args->recvBufferSize = recv(Args->client.clientSocket,Args->recvBuffer,MAX_BUFFER_SIZE,0);
		WaitForSingleObject(msgInProgress,INFINITE);	// engine working
		ResetEvent(engineWorkingEvent);

		if ( Args->recvBufferSize > 0 )
		{
			SetEvent(threadEvent);
		}
		else if( Args->recvBufferSize == 0 )
		{
			printf("Connection closed\n");
			Args->errorOccure=TRUE;
			SetEvent(threadEvent);
			ReleaseMutex(msgInProgress);
			ExitThread(OK);
		}
		else
		{
			printf("recv failed with error: %d\n",WSAGetLastError());
			Args->errorOccure=TRUE;
			SetEvent(threadEvent);
			ReleaseMutex(msgInProgress);
			ExitThread(ERROR);
		}
		WaitForSingleObject(engineWorkingEvent,INFINITE);
		ReleaseMutex(msgInProgress);

	}while(Args->recvBufferSize > 0);
}

void parseRecv(ARGUMENTS_S* Args)
{
	char command[MAX_BUFFER_SIZE] = {0},notRelevent[MAX_BUFFER_SIZE] = {0};
	char numberStr[3] = {0},pawnType[2] = {0};
	int stepSize;

	sscanf(Args->recvBuffer,"%s",command);
	
	if(!strcmp(command,"Your"))
		Args->client.myTurn = TRUE;
	else if( !strcmp(command,"Player")){
		sscanf(Args->recvBuffer,"%s %s %s %s %s %s",command,pawnType,notRelevent,notRelevent,notRelevent,numberStr);
		numberStr[2]='\0';
		stepSize = atoi(numberStr);
		playGame(pawnType[0],stepSize,&Args->board,Args->writingLock);

		printDebug("DEBUG: client:type %s draw a %d \n",pawnType,stepSize);
		printDebug("DEBUG: current pawn is %c my pawn is %c\n",pawnType[0],Args->client.pawnType);
	}

}



void cleanUp(HANDLE threadsRoutinesArray[NUMBER_OF_THREADS], ARGUMENTS_S* Args)
{
	CloseHandle(threadsRoutinesArray[SCANF_INDEX]);
	CloseHandle(threadsRoutinesArray[RECV_INDEX]);
	CloseHandle(Args->threadEvents[SCANF_INDEX]);
	CloseHandle(Args->threadEvents[RECV_INDEX]);
	CloseHandle(Args->engineWorkingEvent);
	CloseHandle(Args->msgInProgress);
	CloseHandle(Args->writingLock);
	fclose(Args->logFile);
	closeMySocket(Args->client.clientSocket);
}

int clientRoutine(char userName[PLAYER_NAME_SIZE], int portNumber,char* logFileName)
{
	int counter = 0;		//need to remove later
	ARGUMENTS_S Args;
	//boardStruct board;
	FILE *logFile = NULL;
	int WaitRes,threadFinishedWaiting = -1,threadIndex;
	int tossResult;
	time_t t;
	HANDLE threadEvents[NUMBER_OF_THREADS] = {0};
	HANDLE threadsRoutinesArray[NUMBER_OF_THREADS] = {0};
	LPTHREAD_START_ROUTINE threadRoutines[] = { (LPTHREAD_START_ROUTINE)UIThread,
		(LPTHREAD_START_ROUTINE)ClientCommunicationThread};

	printDebug("DEBUG: starting main\n");
	ZeroMemory(&Args, sizeof(Args));

	srand((unsigned) time(&t));

	//opening log file and starting the connection with the server
	if(fopen_s(&logFile,logFileName,"w") != 0)
	{
		printf("Can't open log file\n");
		exit(EXIT_ERROR);
	}

	//initiate the game boards
	initBoard(&Args.board);
	//creating locks
	initiateLocks(&Args);
	Args.logFile = logFile;

	memcpy(Args.client.userName,userName,strlen(userName)+1);

	connectToServer(&Args,portNumber);         //connecting to server and sending the required message

	//creating threads and initiating them
	initiateClientEvents(threadEvents,&Args);
	initiateClientThreads(threadsRoutinesArray,threadRoutines,&Args);

	printDebug("DEBUG: starting while\n");
	while(!Args.errorOccure)
	{
		WaitRes = WaitForMultipleObjects(NUMBER_OF_THREADS,threadEvents,FALSE,INFINITE);
		threadIndex = WaitRes-WAIT_OBJECT_0;
		ResetEvent(threadEvents[threadIndex]);		//reset the event that started the loop

		if (Args.errorOccure)
		{
			printDebug("DEBUG: trying to close the SCANF_INDEX thread\n");
			if(!TerminateThread(threadsRoutinesArray[SCANF_INDEX],EXIT_ERROR))
				printf("can't terminate UIThread \n");
			printDebug("DEBUG: trying to close the RECV_INDEX thread\n");
			if(!TerminateThread(threadsRoutinesArray[RECV_INDEX],EXIT_ERROR))
				printf("can't terminate ClientCommunicationThread \n");
			break;
		}

		switch (threadIndex)
		{
		case(SCANF_INDEX)://take care of scanf

			if(!strcmp(Args.sendBuffer,"play"))
			{
				if (Args.client.myTurn)
				{
					tossResult = rand()%6 +1;
					printDebug("DEBUG: tossResult=%d",tossResult);
					sprintf(Args.sendBuffer,"Player %c (%s) drew a %d.",Args.client.pawnType,Args.client.userName,tossResult);
					if (playGame(Args.client.pawnType,tossResult,&Args.board,Args.writingLock) == RETURN_WINNER)
					{
						printf("winner is found\n");
						Args.client.winner = TRUE;
					}
					Args.client.myTurn = FALSE;//turn finnished
				}else
					break;
			}

			sendAndLog(&Args,Args.sendBuffer);
			ZeroMemory(Args.sendBuffer,sizeof(Args.sendBuffer));
			break;

		case(RECV_INDEX)://take care of recv

			printDebug("DEBUG: Received from server:%s",Args.recvBuffer);
			fprintfWithLock(&Args,"Received from server:%s",Args.recvBuffer);
			parseRecv(&Args);
			ZeroMemory(Args.recvBuffer,sizeof(Args.recvBuffer));
			break;
		default:
			printf("why am I here?\n");
		}
		printDebug("DEBUG: threadIndex =%d SCANF_INDEX=%d RECV_INDEX=%d\n while counter=%d\n",threadIndex,SCANF_INDEX,RECV_INDEX,counter++);
		printDebug("DEBUG: pawns location- @=%d #=%d %=%d *%d\n",Args.board.pawnLocation[0],Args.board.pawnLocation[1],Args.board.pawnLocation[2],Args.board.pawnLocation[3]);
		Sleep(10);
		threadIndex = -1;

		SetEvent(Args.engineWorkingEvent);      //relevant thread starts working again
	}
	printDebug("DEBUG: closing the handles\n");
	cleanUp(threadsRoutinesArray,&Args);
	exit(0);
}