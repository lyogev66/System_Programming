#include "StringConversionTools.h"
#include "client.h"
#include "gamePlay.h"
#include "common.h"
#include <stdio.h>
#include <stdarg.h>        //implement printf + fprintf
#include <string.h>

#define DEBUG 1

void printDebug(const char *fmt, ...)
{
	if (DEBUG)
	{
		va_list ap;
		va_start(ap, fmt);
		vfprintf(stdout, fmt, ap);
		va_end(ap);
	}
}

void printToLogAndScreen(FILE * logFile,const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	vfprintf(stdout, fmt, ap);
	vfprintf(logFile, fmt, ap);
	va_end(ap);
}
LPTSTR padEventNameWithProcessId(char* eventName)
{
	char stringName[USERNAME_SIZE]={0};
	LPTSTR lptstrEventName;

	sprintf(stringName,"%s%ld", eventName, GetProcessId(GetCurrentProcess()));
	lptstrEventName=ConvertCharStringToLPTSTR(stringName);	
	return lptstrEventName;
}



//void closeMySocket(SOCKET socket)
//{
//            int error;
//
//    error=closesocket(socket);
//            CHECK_CLOSE_SOCKET(error);
//            WSACleanup();
//}



void parseFromUser(ARGUMENTS_S* Args)
{
	char ch;
	int bufferIndex=0;

	ch = fgetc(stdin);

	while((ch!='\n') && (ch!= EOF) && (ch!= '\r'))
	{
		Args->sendBuffer[bufferIndex++] = ch;
		ch = fgetc(stdin);
	}
	Args->sendBuffer[bufferIndex] = '\0';  
}
void sendAndLog(SOCKET clientSocket,char* stringToSend,FILE *logFile)
{
	char sendbuffer[MAX_BUFFER_SIZE]={0};

	sprintf(sendbuffer,"%s\n",stringToSend);
	send(clientSocket,sendbuffer,strlen(sendbuffer)+1,0);
	fprintf(logFile,"Sent to server:%s\n",stringToSend);
	ZeroMemory(stringToSend,sizeof(stringToSend));
}

void connectToServer(clientStruct *myClient,int portNumber,FILE * logFile)
{
	struct sockaddr_in clientAdd;
	WSADATA wsaData;
	int retval;
	char buffer[MAX_BUFFER_SIZE]={0};

	if ((retval = WSAStartup(0x202, &wsaData)) != 0)
	{
		WSACleanup();
		exit(EXIT_ERROR);
	}
	myClient->clientSocket = socket(AF_INET,SOCK_STREAM,0);
	if (myClient->clientSocket == INVALID_SOCKET)
	{
		WSACleanup();
		exit(EXIT_ERROR);
	}
	clientAdd.sin_family = AF_INET;
	clientAdd.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
	clientAdd.sin_port = htons(portNumber);
	if(connect(myClient->clientSocket,(struct sockaddr*)&clientAdd,sizeof(clientAdd)) == SOCKET_ERROR)
	{
		printToLogAndScreen(logFile,"Failed connecting to server on port %d\n",portNumber);
		closesocket(myClient->clientSocket);
		WSACleanup();
		exit (EXIT_ERROR);
	}
	else
	{
		printToLogAndScreen(logFile,"Connected to server on port %d\n",portNumber);
		sprintf(buffer,"username=%s",myClient->userName);
		sendAndLog(myClient->clientSocket,buffer,logFile);
	}
}

void getGamePieceFromServer(clientStruct *myClient,FILE * logFile)
{
	char buffer[MAX_BUFFER_SIZE]={0};
	char tempString[USERNAME_SIZE]={0};
	int iResult;

	iResult = recv(myClient->clientSocket,buffer,MAX_BUFFER_SIZE,0);
	if ( iResult > 0 )
	{
		sscanf(buffer,"%s",tempString);
		if(!strcmp(tempString,myClient->userName))   //if the first word in the message is the username, parse the pawn type
		{
			sscanf(buffer,"%s %s %s %s %s %s",tempString,tempString,tempString,tempString,tempString,tempString);
			myClient->pawn_type=tempString[0];
		}
		else
		{
			printToLogAndScreen(logFile,"Connection to server refused. Exiting.\n");
		}
	}
	else
		printf("recv failed with error: %d\n", WSAGetLastError());
}

void initiateClientThreads(HANDLE *threadsRoutinesArray,LPTHREAD_START_ROUTINE *threadRoutines,ARGUMENTS_S* Args)
{
	int i;
	DWORD threadID = 0;

	for(i=0;i<NUMBER_OF_THREADS;i++)
	{
		threadsRoutinesArray[i]=CreateThread(NULL,0,threadRoutines[i],Args,0,&threadID);
		CHECK_THREAD_CREATION(threadsRoutinesArray[i]);
	}
}

void parseMessage(char sendBuffer[MAX_BUFFER_SIZE],char message[MESSAGE_SIZE],char userName[USERNAME_SIZE],E_MESSAGE_TYPE type)
{
	char command[MESSAGE_SIZE] = {0};
	int i=0,j=0;
	switch(type)
	{
	case PLAYER_TO_PLAYER_MESSAGE_E:
		{
			sscanf(sendBuffer,"%s %s",command,userName);
			j=strlen(command)+strlen(userName)+2;
			while(sendBuffer[j]!='\0')
			{
				message[i++]=sendBuffer[j++];
			}
			message[i]='\0';
			break;
		}
	case BROADCAT_MESSAGE_E:
		{
			sscanf(sendBuffer,"%s",command);
			j=strlen(command)+1;
			while(sendBuffer[j]!='\0')
			{
				message[i++]=sendBuffer[j++];
			}
			message[i]='\0';
			break;
		}
	}
}

BOOL CheckInputMessage(ARGUMENTS_S* Args,FILE* logFile)
{
	char command[MAX_BUFFER_SIZE]={0};
	char message[MESSAGE_SIZE]={0};
	char username[USERNAME_SIZE]={0};

	sscanf(Args->sendBuffer,"%s",command);
	if(!strcmp(command,"players") )
	{
		//valid arguments
		if(strlen(Args->sendBuffer)==strlen("players"))
			return TRUE;
		else
			printToLogAndScreen(logFile,"Illegal argument for command players. Command format is players.\n");
	}
	else if(!strcmp(command,"play"))
	{
		if(strlen(Args->sendBuffer)==strlen("play"))
			return TRUE;
		else
			printToLogAndScreen(logFile,"Illegal argument for command play. Command format is play.\n");
	}
	else if(!strcmp(command,"message"))
	{
		parseMessage(Args->sendBuffer,message,username,PLAYER_TO_PLAYER_MESSAGE_E);
		if(strlen(Args->sendBuffer)==(strlen(command)+strlen(username)+strlen(message)+2))
			return TRUE;
		else
			printToLogAndScreen(logFile,"Illegal argument for command message. Command format is message <user> <message>.\n");
	}
	else if(!strcmp(command,"broadcast"))
	{             
		parseMessage(Args->sendBuffer,message,username,BROADCAT_MESSAGE_E);
		if(strlen(Args->sendBuffer)==(strlen(command)+strlen(message)+1))
			return TRUE;
		else
			printToLogAndScreen(logFile,"Illegal argument for command message. Command format is broadcast <message>.\n");//not ok
	}
	else if(!strcmp(command,"quit"))
	{
		ExitThread(OK);
	}
	else
		printToLogAndScreen(logFile,"Command %s is not recognized. Possible commands are: players, message, broadcast and play.\n",command);
	return FALSE;
}

void UIThread(ARGUMENTS_S* Args)
{
	int err;
	HANDLE engineEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,Args->engineProcessedScanf);
	HANDLE threadEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,Args->scanfReady);
	printDebug("starting UIThread\n");
	//err=WaitForSingleObject(threadSemaphorehArray[0],0);
	//CHECK_WAIT_FOR_SINGLE(err);
	while(1)
	{
		WaitForSingleObject(engineEvent,INFINITE);
		Sleep(10);
		parseFromUser(Args);
		if (CheckInputMessage(Args,Args->logFile))
			ResetEvent(engineEvent);
		SetEvent(threadEvent);
		//ReleaseMutex(threadSemaphorehArray[0]);
		//WaitForMultipleObjects(wait for all of the printf and so)
	}
}

void ClientCommunicationThread(ARGUMENTS_S* Args)
{
	HANDLE engineEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,Args->engineProcessedRecv);
	HANDLE threadEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,Args->recvReady);

	printDebug("starting ClientCommunicationThread\n");
	do{
		WaitForSingleObject(engineEvent,INFINITE);
		Sleep(10);
		Args->recvBufferSize=recv(Args->client.clientSocket,Args->recvBuffer,MAX_BUFFER_SIZE,0);
		if ( Args->recvBufferSize > 0 )
		{
			ResetEvent(engineEvent);
			SetEvent(threadEvent);
		}
		else if( Args->recvBufferSize == 0 )
		{
			printf("Connection closed\n");
			ExitThread(OK);
		}
		else
		{
			printf("recv failed with error: %d\n",WSAGetLastError());
			ExitThread(ERROR);
		}
	}while(Args->recvBufferSize > 0);
}



void parseRecv(ARGUMENTS_S* Args,boardStruct *board)
{
	char command[MAX_BUFFER_SIZE]={0},not_relevent[MAX_BUFFER_SIZE]={0},number_str[2]={0},pawn_type[2]={0};
	int step_size;

	sscanf(Args->recvBuffer,"%s",command);
	if(!strcmp(command,"Player")){
		sscanf(Args->recvBuffer,"%s %s %s %s %s %s",command,pawn_type,not_relevent,not_relevent,not_relevent,number_str);
		step_size=atoi(number_str);
		printDebug("client:type %s draw a %d \n",pawn_type,step_size);
		playGame(pawn_type,step_size,board);
	}

	//Player <game_piece> (<username>) drew a <dice result>.
	//���� ����� ������ ����� �� ��� ����, �� ������ �� ��������� �����
	//����� �� ��� ����� �� ����� �������� ����.
}

int clientRoutine(char userName[NUMBER_OF_THREADS], int portNumber,char* logFileName)
{
	FILE *logFile=NULL;
	clientStruct myClient;
	int error,threadFinishedWaiting=-1,counter=100;

	ARGUMENTS_S Args;
	HANDLE threadsRoutinesArray[NUMBER_OF_THREADS];
	LPTHREAD_START_ROUTINE threadRoutines[] = { (LPTHREAD_START_ROUTINE)UIThread,
		(LPTHREAD_START_ROUTINE)ClientCommunicationThread};
	boardStruct board;
	int WaitRes;

	HANDLE threadEvents[NUMBER_OF_THREADS]={0};
	HANDLE engineEvents[NUMBER_OF_THREADS]={0};

	printDebug("main\n");

	ZeroMemory(&Args, sizeof(Args));
	Args.scanfReady=padEventNameWithProcessId(SCANF_READY);
	Args.recvReady=padEventNameWithProcessId(RECV_READY);
	Args.engineProcessedScanf=padEventNameWithProcessId(ENGINE_PROCESSED_SCANF);
	Args.engineProcessedRecv=padEventNameWithProcessId(ENGINE_PROCESSED_RECV);

	threadEvents[0]=CreateEvent(NULL,TRUE,FALSE,Args.scanfReady);
	threadEvents[1]=CreateEvent(NULL,TRUE,FALSE,Args.recvReady);
	engineEvents[0]=CreateEvent(NULL,TRUE,TRUE,Args.engineProcessedScanf);
	engineEvents[1]=CreateEvent(NULL,TRUE,TRUE,Args.engineProcessedRecv);


	//opening log file and starting the connection with the server
	if(fopen_s(&logFile,logFileName,"w") != 0)
	{
		printf("cant open log file\n");
		exit(0);
	}
	strcpy(myClient.userName,userName);
	connectToServer(&myClient,portNumber,logFile);         //connecting to server
	getGamePieceFromServer(&myClient,logFile);


	Args.client=myClient;
	Args.logFile=logFile;

	initiateClientThreads(threadsRoutinesArray,threadRoutines,&Args);
	initBoard(&board);
	printDebug("starting while\n");
	while(counter--)
	{
		WaitRes=WaitForMultipleObjects(NUMBER_OF_THREADS,threadEvents,FALSE,INFINITE);

		ResetEvent(threadEvents[WaitRes-WAIT_OBJECT_0]);
		//ResetEvent(engineEvents[WaitRes-WAIT_OBJECT_0]); //relevant thread starts waiting
		switch (WaitRes-WAIT_OBJECT_0)
		{
		case(0)://take care of scanf
			sendAndLog(myClient.clientSocket,Args.sendBuffer,logFile);
			ZeroMemory(Args.sendBuffer,sizeof(Args.sendBuffer));
			break;
		case(1)://take care of recv
			Sleep(1000);
			printToLogAndScreen(logFile,"Received from server:%s",Args.recvBuffer);		//convert to log
			parseRecv(&Args,&board);
			ZeroMemory(Args.recvBuffer,sizeof(Args.recvBuffer));
			break;
		}
		printDebug("WaitRes-WAIT_OBJECT_0 =%d\n",(WaitRes-WAIT_OBJECT_0));
		Sleep(10);
		SetEvent(engineEvents[WaitRes-WAIT_OBJECT_0]);      //relevant thread stops waiting
	}

	//closeMySocket(myClient.socket);
	return OK;
}