import socket

PORT=3000
HOST='localhost'
my_socsket=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
my_socsket.bind((HOST, PORT))

my_socsket.listen(10)
client,clientAdd=my_socsket.accept()
client.send("hii")
client.recv(1024)

