#include "client.h"


//initCell
//initMatrix
createMatrix();

printMartix();
 

void userInterface()
{

}
