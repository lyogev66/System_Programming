#ifndef CLIENT_H
#define CLIENT_H
 
#include "common.h"
#include <stdlib.h>
#include <stdio.h>
#include <tchar.h>
 
#define SCANF_READY									_T("scanfReady")
#define RECV_READY                                  _T("recvReady")
#define ENGINE_PROCESSED_SCANF                      _T("engineProcessedScanf")
#define ENGINE_PROCESSED_RECV                       _T("engineProcessedRecv")
#define USER_IPNUT_WAITING                          _T("UserInputWaiting")
#define INCOMING_MESSAGE_FROM_SERVER                _T("IncomingMessageFromServer")
#define NUMBER_OF_THREADS 2
#define SERVER_ADDRESS  "127.0.0.1"

int clientRoutine(char userName[USERNAME_SIZE], int portNumber,char* logFile);
 
typedef enum cellType{
                NORMAL_CELL,
                STARTSNAKE_CELL,
                ENDSNAKE_CELL,
                STARTLADDER_CELL,
                ENDLADDER_CELL,
}cellType;
 
typedef struct matrixCell{
                cellType type;
                int endLocation;
                char display[DISPLAY_SIZE];
                BOOL pawn_array[NUMBER_OF_PAWNS];        
}matrixCell;
 
typedef struct clientStruct{                         //double use cause crash
                char userName[USERNAME_SIZE];
                char pawn_type;
                SOCKET clientSocket;
}clientStruct;
 
typedef struct ARGUMENTS_S{
                clientStruct client;
                DWORD WaitCode;
                FILE *logFile;
                char recvBuffer[MAX_BUFFER_SIZE];
                char sendBuffer[MAX_BUFFER_SIZE];
                int recvBufferSize,sendBufferSize;
}ARGUMENTS_S;
 
 
//enum pawn_strings{  //A=@ B=# C=% D=*
//            A =1,      //@
//            B,                            //#
//            AB,                         //@#
//            C,                            //%
//            AC,                         //@%
//            BC,                         //#%
//            ABC,      //@#%
//            D,                            //*
//            AD,                         //@*
//            BD,                         //#*
//            ABD,      //@#*
//            CD,                         //%*
//            ACD,      //@%*
//            BCD,      //#%*
//            ABCD,   //@#%*
//}pawn_strings;
 
#endif