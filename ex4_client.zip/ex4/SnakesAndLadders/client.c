#include "client.h"
#include "common.h"
#include <stdio.h>
#include <math.h>          //for power
#include <stdarg.h>        //implement printf + fprintf
#include <string.h>
 
 
void printToLogAndScreen(FILE * logFile,const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
                vfprintf(stdout, fmt, ap);
                vfprintf(logFile, fmt, ap);
    va_end(ap);
}
 
//int convertArrayToNum(BOOL pawn_array[NUMBER_OF_PAWNS])
//{
//            int i,num=0;
//
//            for(i=0;i<NUMBER_OF_PAWNS;i++)
//            {
//                            //create a binary representation of pawn_array
//                            if (pawn_array[i])
//                            {
//                            num=num+(int)(pow((double)2,i));
//                            }
//            }
//            return num;
//}
//
//char *convertNumToString(int num)
//{
//                                            char *pawnStringsList[]={                            //A=@ B=# C=% D=*
//                                                                                            "   @  ",
//                                                                                            "   #  ",
//                                                                                            "  @#  ",
//                                                                                            "   %  ",
//                                                                                            "  @%  ",
//                                                                                            "  #%  ",
//                                                                                            "  @#% ",
//                                                                                            "   *  ",
//                                                                                            "  @*  ",
//                                                                                            "  #*  ",
//                                                                                            "  @#* ",
//                                                                                            "  %*  ",
//                                                                                            "  @%* ",
//                                                                                            "  #%* ",
//                                                                                            " @#%* ",                                          
//                                                                                            };
//            return pawnStringsList[num-1];
//}
//
//char *getPawnString(matrixCell cell)                   //incomplete
//{
//            int num;
//
//            num=convertArrayToNum(cell.pawn_array);
//            return convertNumToString(num);
//}
//
//int CountPawnInCell(matrixCell cell)
//{
//            int i=0,counter=0;
//
//            for(i=0;i<NUMBER_OF_PAWNS;i++)
//            {
//                            if(cell.pawn_array[i]==TRUE)
//                            {
//                                            counter++;
//                            }
//            }
//            return counter;
//}
//
//void updateCellDisplay(matrixCell *cell,int cellIndex)                                  //need to fix the update in case of
//{
//            int numberOfPawns=CountPawnInCell(*cell);
//
//            if(!numberOfPawns)
//            {
//                            if (cellIndex<10)
//                                            sprintf(cell->display,"  0%d  ",cellIndex);
//                            else if(cellIndex<100)
//                                            sprintf(cell->display,"  %d  ",cellIndex);
//                            else
//                                            sprintf(cell->display,"  %d ",cellIndex);
//                           
//                            switch (cell->type)
//                            {
//                            case STARTLADDER_CELL:
//                                            {
//                                                            cell->display[1]='^';
//                                                            break;
//                                            }
//                            case ENDLADDER_CELL:
//                                            {
//                                                            cell->display[1]='=';
//                                                            break;
//                                            }
//                            case STARTSNAKE_CELL:
//                                            {
//                                                            cell->display[4]='v';
//                                                            break;
//                                            }
//                            case ENDSNAKE_CELL:
//                                            {
//                                                            cell->display[4]='_';
//                                                            break;
//                                            }
//                            }
//            }
//            else
//            {
//                            strcpy(cell->display,getPawnString(*cell));
//            }
//}
//
//void updateBoardDisplay(matrixCell gameBoard[GAME_ARRAY_SIZE])
//{
//            int i;
//            gameBoard[3].pawn_array[2]=1;
//            gameBoard[3].pawn_array[1]=1;
//            gameBoard[6].pawn_array[0]=1;
//            for(i=0;i<=GAME_ARRAY_SIZE;i++)
//            {
//                            updateCellDisplay(&gameBoard[i],i);
//            }
//}
//
//void setBoard(matrixCell gameBoard[GAME_ARRAY_SIZE])
//{
//            int ladderStartArr[8]={4,9,20,28,40,51,63,71};
//            int ladderEndArr[8]={14,31,38,84,59,67,81,91};
//            int snakeStartArr[8]={17,54,62,64,87,93,96,99};
//            int snakeEndArr[8]={7,34,19,60,24,73,75,78};
//            int i,numberOfLadders=8,numberOfSnakes=8;
//
//            for(i=0;i<numberOfLadders;i++)
//            {
//                            gameBoard[ladderStartArr[i]].type=STARTLADDER_CELL;
//                            gameBoard[ladderStartArr[i]].endLocation=ladderEndArr[i];
//                            gameBoard[ladderEndArr[i]].type=ENDLADDER_CELL;
//            }
//            for(i=0;i<numberOfSnakes;i++)
//            {
//                            gameBoard[snakeStartArr[i]].type=STARTSNAKE_CELL;
//                            gameBoard[snakeStartArr[i]].endLocation=snakeEndArr[i];
//                            gameBoard[snakeEndArr[i]].type=ENDSNAKE_CELL;
//            }
//}
//
//matrixCell initCell()
//{
//            matrixCell cell;
//            int i;
//
//            cell.type=NORMAL_CELL;
//            cell.endLocation=0;
//            for(i=0;i<DISPLAY_SIZE;i++)
//            {
//                            cell.display[i]='\0';
//            }
//            for(i=0;i<NUMBER_OF_PAWNS;i++)
//            {
//                            cell.pawn_array[i]=FALSE;
//            }
//            return cell;
//}
//
//void printBroad(matrixCell gameBoard[GAME_ARRAY_SIZE])
//{
//            int i,j,currentIndex;
//
//            for(i=9;i>=0;i--)
//            {
//                            if(i==9)
//                                            printf("\n-----------------------------------------------------------------------\n");
//                            for(j=10;j>=1;j--)
//                            {
//                                            if(j==10)
//                                                            printf("|");
//                                            if (i%2==1)//odd row
//                                                            currentIndex=i*10+j;
//                                            else
//                                                            currentIndex=i*10+11-j;
//                                            printf("%s|",gameBoard[currentIndex].display);
//                            }
//                            printf("\n-----------------------------------------------------------------------\n");
//            }
//}
//
//void initBoard(matrixCell gameBoard[GAME_ARRAY_SIZE])
//{
//            int i=0;
//            for(i=0;i<=GAME_ARRAY_SIZE;i++)
//            {
//                            gameBoard[i]=initCell();
//            }
//            setBoard(gameBoard);
//            updateBoardDisplay(gameBoard);
//            printBroad(gameBoard);
//}
//
//void closeMySocket(SOCKET socket)
//{
//            int error;
//
//    error=closesocket(socket);
//            CHECK_CLOSE_SOCKET(error);
//            WSACleanup();
//}
//
void parseFromUser(ARGUMENTS_S* Args)
{
                char ch;
                int bufferIndex=0;
 
                ch = fgetc(stdin);
 
                while((ch!='\n') && (ch!= EOF) && (ch!= '\r'))
                {
                                Args->sendBuffer[bufferIndex++] = ch;
                                ch = fgetc(stdin);
                }
                Args->sendBuffer[bufferIndex] = '\0';  
}
 
void connectToServer(clientStruct *myClient,int portNumber,FILE * logFile)
{
                struct sockaddr_in clientAdd;
    WSADATA wsaData;
    int retval;
                char buffer[MAX_BUFFER_SIZE]={0};
 
    if ((retval = WSAStartup(0x202, &wsaData)) != 0)
    {
                    WSACleanup();
                    exit(EXIT_ERROR);
    }
    myClient->clientSocket = socket(AF_INET,SOCK_STREAM,0);
    if (myClient->clientSocket == INVALID_SOCKET)
    {
                    WSACleanup();
                    exit(EXIT_ERROR);
    }
                clientAdd.sin_family = AF_INET;
    clientAdd.sin_addr.s_addr = inet_addr(SERVER_ADDRESS);
    clientAdd.sin_port = htons(portNumber);
    if(connect(myClient->clientSocket,(struct sockaddr*)&clientAdd,sizeof(clientAdd)) == SOCKET_ERROR)
    {
                                                                                printToLogAndScreen(logFile,"Failed connecting to server on port %d\n",portNumber);
                                                                                //printf("Failed connecting to server on port %d\n",portNumber);
                                                                                //fprintf(logFile,"Failed connecting to server on port %d\n",portNumber);
                                                                                closesocket(myClient->clientSocket);
                    WSACleanup();
                    exit (EXIT_ERROR);
    }
                else
                {
                printToLogAndScreen(logFile,"Connected to server on port %d\n",portNumber);
//   printf("Connected to server on port %d\n",portNumber);
                //fprintf(logFile,"Connected to server on port %d\n",portNumber);
                sprintf(buffer,"username=%s\n",myClient->userName);
                send(myClient->clientSocket,buffer,strlen(buffer)+1,0);
                }
}
 
void getGamePieceFromServer(clientStruct *myClient,FILE * logFile)
{
                char buffer[MAX_BUFFER_SIZE]={0};
                char tempString[USERNAME_SIZE]={0};
                int iResult;
 
                iResult = recv(myClient->clientSocket,buffer,MAX_BUFFER_SIZE,0);
                if ( iResult > 0 )
                {
                                sscanf(buffer,"%s",tempString);
                                if(!strcmp(tempString,myClient->userName))   //if the first word in the message is the username, parse the pawn type
                                {
                                                sscanf(buffer,"%s %s %s %s %s %s",tempString,tempString,tempString,tempString,tempString,tempString);
                                                myClient->pawn_type=tempString[0];
                                }
                                else
                                {
                                                printToLogAndScreen(logFile,"Connection to server refused. Exiting.\n");
                                }
                }
                else
                                printf("recv failed with error: %d\n", WSAGetLastError());
}
 
void initiateThreads(HANDLE *threadsRoutinesArray,LPTHREAD_START_ROUTINE *threadRoutines,ARGUMENTS_S* Args)
{
                int i;
                DWORD threadID = 0;
 
                for(i=0;i<NUMBER_OF_THREADS;i++)
                {
                                threadsRoutinesArray[i]=CreateThread(NULL,0,threadRoutines[i],Args,0,&threadID);
                                CHECK_THREAD_CREATION(threadsRoutinesArray[i]);
                }
}
 
void parseMessage(char sendBuffer[MAX_BUFFER_SIZE],char message[MESSAGE_SIZE],char userName[USERNAME_SIZE],e_messageType type)
{
                char command[MESSAGE_SIZE] = {0};
                int i=0,j=0;
                switch(type)
                {
                case PLAYER_TO_PLAYER_MESSAGE_E:
                                {
                                                sscanf(sendBuffer,"%s %s",command,userName);
                                                j=strlen(command)+strlen(userName)+2;
                                                while(sendBuffer[j]!='\0')
                                                {
                                                                message[i++]=sendBuffer[j++];
                                                }
                                                message[i]='\0';
                                                break;
                                }
                case BROADCAT_MESSAGE_E:
                                {
                                                sscanf(sendBuffer,"%s",command);
                                                j=strlen(command)+1;
                                                while(sendBuffer[j]!='\0')
                                                {
                                                                message[i++]=sendBuffer[j++];
                                                }
                                                message[i]='\0';
                                                break;
                                }
                }
}
 
BOOL CheckInputMessage(ARGUMENTS_S* Args,FILE* logFile)
{
                char command[MAX_BUFFER_SIZE]={0};
                char message[MESSAGE_SIZE]={0};
                char username[USERNAME_SIZE]={0};
 
                sscanf(Args->sendBuffer,"%s",command);
                if(!strcmp(command,"players") )
                {
                                //valid arguments
                                if(strlen(Args->sendBuffer)==strlen("players"))
                                                return TRUE;
                                else
                                                printToLogAndScreen(logFile,"Illegal argument for command players. Command format is players.\n");
                }
                else if(!strcmp(command,"play"))
                {
                                if(strlen(Args->sendBuffer)==strlen("play"))
                                                return TRUE;
                                else
                                                printToLogAndScreen(logFile,"Illegal argument for command play. Command format is play.\n");
                }
                else if(!strcmp(command,"message"))
                {
                                parseMessage(Args->sendBuffer,message,username,PLAYER_TO_PLAYER_MESSAGE_E);
                                if(strlen(Args->sendBuffer)==(strlen(command)+strlen(username)+strlen(message)+2))
                                                return TRUE;
                                else
                                                printToLogAndScreen(logFile,"Illegal argument for command message. Command format is message <user> <message>.\n");
                }
                else if(!strcmp(command,"broadcast"))
                {             
                                parseMessage(Args->sendBuffer,message,username,BROADCAT_MESSAGE_E);
                                if(strlen(Args->sendBuffer)==(strlen(command)+strlen(message)+1))
                                                return TRUE;
                                else
                                                printToLogAndScreen(logFile,"Illegal argument for command message. Command format is broadcast <message>.\n");//not ok
                }
                else if(!strcmp(command,"quit"))
                {
                                //ReleaseMutex()
                                ExitThread(OK);
                }
                printToLogAndScreen(logFile,"Command %s is not recognized. Possible commands are: players, message, broadcast and play.\n",command);
                return FALSE;
}
 
void UIThread(ARGUMENTS_S* Args)
{
                int err;
                HANDLE engineEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,ENGINE_PROCESSED_SCANF);
                HANDLE threadEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,SCANF_READY);
 
                //err=WaitForSingleObject(threadSemaphorehArray[0],0);
                //CHECK_WAIT_FOR_SINGLE(err);
                while(1)
                {
                                WaitForSingleObject(engineEvent,INFINITE);
                                Sleep(10);
                                parseFromUser(Args);
                                if (CheckInputMessage(Args,Args->logFile))
                                                SetEvent(threadEvent);
                                //ReleaseMutex(threadSemaphorehArray[0]);
                                //WaitForMultipleObjects(wait for all of the printf and so)
                }
}
 
void ClientCommunicationThread(ARGUMENTS_S* Args)
{
                HANDLE engineEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,ENGINE_PROCESSED_RECV);
                HANDLE threadEvent=OpenEvent(EVENT_ALL_ACCESS,FALSE,RECV_READY);
 
                do{
                                WaitForSingleObject(engineEvent,INFINITE);
                                Sleep(10);
                                Args->recvBufferSize=recv(Args->client.clientSocket,Args->recvBuffer,MAX_BUFFER_SIZE,0);
                                if ( Args->recvBufferSize > 0 )
                                {
                                                SetEvent(threadEvent);
                                }
                                else if( Args->recvBufferSize == 0 )
                                {
                                                printf("Connection closed\n");
                                                ExitThread(OK);
                                }
                                else
                                {
                                                printf("recv failed with error: %d\n",WSAGetLastError());
                                                ExitThread(ERROR);
                                }
                }              while(Args->recvBufferSize > 0);
}
 
void parseRecv(ARGUMENTS_S* Args)
{
                if(!strcmp(Args->recvBuffer,"play")){
                                //dosomething
                                printf("play");
                }else if(!strcmp(Args->recvBuffer,"New player"))
                {
                                printf("New player");//dosomthing
                }
 
}
 
int clientRoutine(char userName[NUMBER_OF_THREADS], int portNumber,char* logFileName)
{
                FILE *logFile=NULL;
                clientStruct myClient;
                int error,threadFinishedWaiting=-1,counter=100;
                //void (*functionPtr)(ARGUMENTS_S*);
                ARGUMENTS_S Args;
                HANDLE threadsRoutinesArray[NUMBER_OF_THREADS];
                LPTHREAD_START_ROUTINE threadRoutines[] = { (LPTHREAD_START_ROUTINE)UIThread,
                                                                                                                                                                                                (LPTHREAD_START_ROUTINE)ClientCommunicationThread};
                matrixCell gameBoard[GAME_ARRAY_SIZE];
                int WaitRes;
                //HANDLE UserInputWaiting,IncomingMessageFromServer;
 
                HANDLE threadEvents[NUMBER_OF_THREADS]={CreateEvent(NULL,TRUE,FALSE,SCANF_READY),                                          //start manual nonsignaled
                                                                                                                                                                                CreateEvent(NULL,TRUE,FALSE,RECV_READY)};
                HANDLE engineEvents[NUMBER_OF_THREADS]={CreateEvent(NULL,TRUE,TRUE,ENGINE_PROCESSED_SCANF),                //start manual signaled
                                                                                                                                                                                CreateEvent(NULL,TRUE,TRUE,ENGINE_PROCESSED_RECV)};
 
                //opening log file and starting the connection with the server
                if(fopen_s(&logFile,logFileName,"w") != 0)
                {
                                printf("cant open log file\n");
                                exit(0);
                }
                strcpy(myClient.userName,userName);
                connectToServer(&myClient,portNumber,logFile);         //connecting to server
                getGamePieceFromServer(&myClient,logFile);
 
                ZeroMemory(&Args, sizeof(Args));
                Args.client=myClient;
                Args.logFile=logFile;
 
                initiateThreads(threadsRoutinesArray,threadRoutines,&Args);
 
 
                while(counter--)
                {
                                WaitRes=WaitForMultipleObjects(NUMBER_OF_THREADS,threadEvents,FALSE,INFINITE);
                                threadFinishedWaiting=WaitRes-WAIT_OBJECT_0;
                                ResetEvent(threadEvents[WaitRes-WAIT_OBJECT_0]);
                                ResetEvent(engineEvents[WaitRes-WAIT_OBJECT_0]); //relevant thread starts waiting
                                switch (threadFinishedWaiting)
                                {
                                case(0)://take care of scanf
                                                send(myClient.clientSocket,Args.sendBuffer,strlen(Args.sendBuffer)+1,0);
                                                ZeroMemory(Args.sendBuffer,sizeof(Args.sendBuffer));
                                                break;
                                case(1)://take care of recv
                                                Sleep(1000);
                                                printf("%s\n",Args.recvBuffer);
                                                parseRecv(&Args);
                                                ZeroMemory(Args.recvBuffer,sizeof(Args.recvBuffer));
                                                break;
                                }
                                //printf("WaitRes-WAIT_OBJECT_0 =%d\n",(WaitRes-WAIT_OBJECT_0));
                                Sleep(10);
                                SetEvent(engineEvents[WaitRes-WAIT_OBJECT_0]);      //relevant thread starts waiting
                }
 
                //closeMySocket(myClient.socket);
                return OK;
}