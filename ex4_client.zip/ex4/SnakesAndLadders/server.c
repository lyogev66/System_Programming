////#include "server.h"
////#pragma comment(lib,"Ws2_32.lib")
////#pragma warning(disable : 4996)
////
////
////void writeToLogRoutine(DataCollection *gameData)
////{
////	HANDLE  writeToLog = OpenMutex (MUTEX_ALL_ACCESS,FALSE,WRITE_PROTECT);
////	char logMsg[MESSAGE_SIZE]={0};
////
////	if (WaitForSingleObject(writeToLog,INFINITE) == WAIT_OBJECT_0)
////	{
////		switch(gameData->gameMsgBox.messageTypeInProgress)
////		{
////		case GAME_MESSAGE_E:
////			sprintf(logMsg,"Player %c (%s) drew a %d\n",	gameData->playerInfo[gameData->gameMsgBox.gMsg.playerNumberTurn].playerPawn,
////				gameData->playerInfo[gameData->gameMsgBox.gMsg.playerNumberTurn].playerName,
////				gameData->gameMsgBox.gMsg.drewRes);
////			break;
////		case BROADCAT_MESSAGE_E:
////			sprintf(logMsg,"Broadcast message from user %s: %s",gameData->playerInfo[gameData->gameMsgBox.bMsg.playerSenderNumber].playerName,gameData->gameMsgBox.bMsg.message);
////			break;
////		case PLAYER_TO_PLAYER_MESSAGE_E:
////			sprintf(logMsg,"Private message sent from %s to %s: %s",gameData->gameMsgBox.p2pMsg.senderName,gameData->gameMsgBox.p2pMsg.receiverName,gameData->gameMsgBox.p2pMsg.message);
////			break;
////		case SINGLE_PLAYER_MESSAGE_E:
////			break;
////		case PLAYER_TURN_MSG:
////			if(gameData->gameMsgBox.pttpMsg.flag)
////				memcpy(logMsg,gameData->gameMsgBox.pttpMsg.msgToCurrentPlayer,strlen(gameData->gameMsgBox.pttpMsg.msgToCurrentPlayer)+1);
////			else
////				memcpy(logMsg,gameData->gameMsgBox.pttpMsg.msgToOtherPlayers,strlen(gameData->gameMsgBox.pttpMsg.msgToOtherPlayers)+1);
////			break;
////		case NEW_PLAYER_MESSAGE:
////			if(gameData->gameMsgBox.newPlayerMsg.flag)
////				sprintf(logMsg,"%s your game piece is %c\n",gameData->gameMsgBox.newPlayerMsg.playerName,gameData->gameMsgBox.newPlayerMsg.pawn);
////			else
////				sprintf(logMsg,"New player joined the game:%s %c\n",gameData->gameMsgBox.newPlayerMsg.playerName,gameData->gameMsgBox.newPlayerMsg.pawn);
////			break;
////		case GAME_ORDER_MESSAGE:
////			memcpy(logMsg,gameData->gameMsgBox.generalMsg.message,strlen(gameData->gameMsgBox.generalMsg.message)+1);
////			break;
////		case PLAYER_LIST_MSG:
////			sprintf(logMsg,"Players' game pieces' selection broadcasted to all users.\n");
////			break;
////
////		default:
////			printf("why am i here?\n");
////		}
////
////		fwrite(logMsg,sizeof(char),strlen(logMsg) +1,gameData->logFile);
////		ReleaseMutex(writeToLog);
////	}
////	else
////		printf("cant write to log file %d \n",GetLastError());
////}
////void sendBroadcastMessage(DataCollection *gameData)
////{
////	HANDLE	broadcastEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,BROADCAST_EVENT);
////	char message[MESSAGE_SIZE]={0};
////	int i;
////	Sleep(10);
////
////	while(TRUE)
////	{
////		WaitForSingleObject(broadcastEvent,INFINITE);
////		printf("			************** BROADCASTING ****************			\n");
////		sprintf(message,"Broadcast from %s: %s",gameData->playerInfo[gameData->gameMsgBox.bMsg.playerSenderNumber].playerName ,gameData->gameMsgBox.bMsg.message);    
////		for(i=1 ;i <= gameData->activePlayersNum ;i++)
////		{
////			if(gameData->gameMsgBox.bMsg.playerSenderNumber == i)
////				continue;//send broadcast message to all other players else then the sender itself.
////			send(gameData->playerInfo[i].playerSocket,message,strlen(message)+1,0);
////			Sleep(5);
////		}
////
////		gameData->gameMsgBox.messageTypeInProgress = BROADCAT_MESSAGE_E;
////		writeToLogRoutine(gameData);
////		ResetEvent(broadcastEvent);
////	}
////}
////
////int	searchPlayerByName(char* playerName,DataCollection *gameData)
////{
////	int i,retIndex = 0;
////	for(i=1; i<=gameData->activePlayersNum; i++)
////	{
////		if(!strcmp(playerName,gameData->playerInfo[i].playerName ))
////		{
////			retIndex = i;
////			break;
////		}
////	}
////	return retIndex;
////}
////
////void playertoPlayerMessage(DataCollection *gameData)
////{
////	HANDLE	player2playermsgEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,P2P_MESSAGE_EVENT);
////	char message[MESSAGE_SIZE]={0};
////	int playerIndex;
////	Sleep(10);
////
////	while(TRUE)
////	{
////		WaitForSingleObject(player2playermsgEvent,INFINITE);
////		printf("			************** playertoPlayerMessage ****************			\n");
////		playerIndex = searchPlayerByName(gameData->gameMsgBox.p2pMsg.receiverName,gameData);
////		if(playerIndex)
////		{
////			sprintf(message,"Private message from %s: %s",gameData->gameMsgBox.p2pMsg.senderName,gameData->gameMsgBox.p2pMsg.message);
////			send(gameData->playerInfo[playerIndex].playerSocket,message,strlen(message)+1,0);
////		}
////		else
////		{
////			sprintf(message,"User %s doesn't exists in the game.\n",gameData->gameMsgBox.p2pMsg.receiverName);
////			send(gameData->playerInfo[gameData->gameMsgBox.p2pMsg.senderNumber].playerSocket,message,strlen(message)+1,0);
////		}
////
////		gameData->gameMsgBox.messageTypeInProgress = PLAYER_TO_PLAYER_MESSAGE_E;
////		writeToLogRoutine(gameData);
////		ResetEvent(player2playermsgEvent);
////	}
////}
////
////void sendGameMessage(DataCollection *gameData)
////{
////	HANDLE	gameMsgEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,GAME_MSG_EVENT);
////	HANDLE	playerTossEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,PLAYER_TOSS_EVENT);
////	HANDLE  writeToLog = OpenMutex (MUTEX_ALL_ACCESS,FALSE,WRITE_PROTECT);
////	char msgToCurrentPlayer[MESSAGE_SIZE]={0}, msgToOtherPlayers[MESSAGE_SIZE] ={0};
////	int i;
////	Sleep(10);
////
////	while(TRUE)
////	{
////		WaitForSingleObject(gameMsgEvent,INFINITE);
////		printf("			************** sendGameMessage ****************			\n");
////		sprintf(msgToCurrentPlayer,"Drew result %d\n",gameData->gameMsgBox.gMsg.drewRes);
////		sprintf(msgToOtherPlayers,"Player %c (%s) drew a %d\n",	gameData->playerInfo[gameData->gameMsgBox.gMsg.playerNumberTurn].playerPawn,
////																gameData->playerInfo[gameData->gameMsgBox.gMsg.playerNumberTurn].playerName,
////																gameData->gameMsgBox.gMsg.drewRes);
////		for(i=1 ;i <= gameData->activePlayersNum ;i++)
////		{
////			if(gameData->gameMsgBox.gMsg.playerNumberTurn == i)
////				send(gameData->playerInfo[i].playerSocket,msgToCurrentPlayer,strlen(msgToCurrentPlayer)+1,0);
////			else
////				send(gameData->playerInfo[i].playerSocket,msgToOtherPlayers,strlen(msgToOtherPlayers)+1,0);
////			Sleep(5);
////		}
////
////		gameData->gameMsgBox.messageTypeInProgress = GAME_MESSAGE_E;
////		writeToLogRoutine(gameData);
////		SetEvent(playerTossEvent);
////		ResetEvent(gameMsgEvent);
////	}
////}
////
////void sendTurnMsg (DataCollection *gameData)
////{
////	HANDLE sendingMsg = OpenMutex (MUTEX_ALL_ACCESS,FALSE,MESSAGE_IN_PROGRESS);
////	HANDLE  writeToLog = OpenMutex (MUTEX_ALL_ACCESS,FALSE,WRITE_PROTECT);
////	char msgToCurrentPlayer[MESSAGE_SIZE]={0}, msgToOtherPlayers[MESSAGE_SIZE] ={0};
////	int i;
////	Sleep(10);
////
////	sprintf(msgToCurrentPlayer,"Your turn to play.\n");
////	sprintf(msgToOtherPlayers,"It is now %s's turn to play\n",gameData->playerInfo[gameData->playerTurn].playerName);
////	memcpy(gameData->gameMsgBox.pttpMsg.msgToCurrentPlayer,msgToCurrentPlayer,strlen(msgToCurrentPlayer)+1);
////	memcpy(gameData->gameMsgBox.pttpMsg.msgToOtherPlayers,msgToOtherPlayers,strlen(msgToOtherPlayers)+1);
////	memcpy(gameData->gameMsgBox.pttpMsg.playerName,gameData->playerInfo[gameData->playerTurn].playerName,strlen(gameData->playerInfo[gameData->playerTurn].playerName) +1);
////	gameData->gameMsgBox.pttpMsg.playerTurn = gameData->playerTurn;
////	if(WaitForSingleObject(sendingMsg,INFINITE) == WAIT_OBJECT_0)
////	{
////		printf("			************** sendTurnMsg ****************			\n");
////		for(i=1 ;i <= gameData->activePlayersNum ;i++)
////		{
////			if(gameData->playerTurn == i)
////			{
////				gameData->gameMsgBox.pttpMsg.flag = TRUE;
////				send(gameData->playerInfo[i].playerSocket,msgToCurrentPlayer,strlen(msgToCurrentPlayer)+1,0);
////			}
////			else
////			{
////				gameData->gameMsgBox.pttpMsg.flag = FALSE;
////				send(gameData->playerInfo[i].playerSocket,msgToOtherPlayers,strlen(msgToOtherPlayers)+1,0);
////			}
////			Sleep(5);
////		}
////
////		gameData->gameMsgBox.messageTypeInProgress = PLAYER_TURN_MSG;
////		writeToLogRoutine(gameData);
////		ReleaseMutex(sendingMsg);
////	}
////	else
////	{	
////		printf("cannot take broadcastInProgress mutex %d\n",GetLastError());
////	}	
////}
////
////void createPlayersList(DataCollection *gameData,char *resMessage)
////{
////	char message[MESSAGE_SIZE]={0};
////	char playersList[MAXPLAYERSNUMBER+1][MESSAGE_SIZE]={{0}};
////	int i;
////
////	for(i=1; i<=gameData->activePlayersNum ; i++)
////	{
////		if(i != gameData->activePlayersNum)
////			sprintf(playersList[i],"%s-%c, ",gameData->playerInfo[i].playerName,gameData->playerInfo[i].playerPawn);
////		else
////			sprintf(playersList[i],"%s-%c ",gameData->playerInfo[i].playerName,gameData->playerInfo[i].playerPawn);
////	}
////	sprintf(resMessage,"%s %s %s %s\n",playersList[1],playersList[2],playersList[3],playersList[4]);
////}
////
////void sendPlayersListMessage(DataCollection *gameData)
////{
////	HANDLE	playerListRequest = OpenEvent(EVENT_ALL_ACCESS ,FALSE,MSG_LIST_EVENT);
////	HANDLE  writeToLog = OpenMutex (MUTEX_ALL_ACCESS,FALSE,WRITE_PROTECT);
////	char listMsg[MESSAGE_SIZE]={0};
////	int i;
////	Sleep(10);
////
////	while(TRUE)
////	{
////		WaitForSingleObject(playerListRequest,INFINITE);
////		printf("			************** playerListRequest ****************			\n");
////		createPlayersList(gameData,listMsg);
////		memcpy(gameData->gameMsgBox.playerListMsg.message,listMsg,strlen(listMsg)+1);
////		send(gameData->playerInfo[gameData->gameMsgBox.playerListMsg.requestingPlayerNumber].playerSocket,listMsg,strlen(listMsg)+1,0);
////
////		if(BROADCAT_MESSAGE_E == gameData->gameMsgBox.playerListMsg.type)
////		{
////			for(i=1;i<=gameData->activePlayersNum;i++)
////			{
////				if(i == gameData->gameMsgBox.playerListMsg.requestingPlayerNumber)
////					continue;
////				send(gameData->playerInfo[i].playerSocket,listMsg,strlen(listMsg)+1,0);
////			}
////		}
////
////		ResetEvent(playerListRequest);
////	}
////	
////}
////
////void ForceExitAllPlayers(DataCollection *gameData)
////{
////	int i;
////
////	printf("			************** exitAllPlayers ****************			\n");
////	for(i=1; i<=gameData->activePlayersNum;i++)
////	{
////		shutdown(gameData->playerInfo[i].playerSocket,SD_BOTH);
////		closesocket(gameData->playerInfo[i].playerSocket);
////	}
////}
////
////void extractMsg(char* inputMsg,char *userName,char* retMsg,e_messageType type)
////{
////	char command[MESSAGE_SIZE] = {0};
////	char *token;
////
////	switch(type)
////	{
////	case PLAYER_TO_PLAYER_MESSAGE_E:
////		{
////			sscanf(inputMsg,"%s %s",command,userName);
////			token = strtok(inputMsg," ");
////			token = strtok(NULL," ");
////			token = strtok(NULL,"\0");
////			memcpy(retMsg,token,strlen(token)+1);
////			break;
////		}
////	case BROADCAT_MESSAGE_E:
////		{
////			token = strtok(inputMsg," ");
////			token = strtok(NULL,"\0");
////			memcpy(retMsg,token,strlen(token)+1);
////			break;
////		}
////	}
////}
////
////void checkForWinnersRoutine(DataCollection *gameData)
////{
////	HANDLE	winnerEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,WINNER_EVENT);
////	char responeMsg[MESSAGE_SIZE] = {0};
////	int i;
////	Sleep(10);
////
////	while(TRUE)
////	{
////		WaitForSingleObject(winnerEvent,INFINITE);
////		printf("			************** winnerEvent ****************			\n");
////
////		for(i=1; i<=gameData->activePlayersNum;i++)
////		{
////			if(i == gameData->gameMsgBox.winnerMsg.playerNumber)
////			{
////				send(gameData->playerInfo[i].playerSocket,"Congratz you won!\n",strlen("Congratz you won!\n")+1,0);
////					continue;
////			}
////			send(gameData->playerInfo[i].playerSocket,gameData->gameMsgBox.winnerMsg.message,strlen(gameData->gameMsgBox.winnerMsg.message)+1,0);
////		}
////
////		ResetEvent(winnerEvent);
////	}
////}
////
////void parseMessage(char* msg,playersInformation *player)
////{
////	char command[MESSAGE_SIZE] = {0};
////	char parsedMsg[MESSAGE_SIZE] = {0};
////	char userName[MESSAGE_SIZE] = {0};
////	char responeMsg[MESSAGE_SIZE] = {0};
////	HANDLE	msgInProgress = OpenMutex(MUTEX_ALL_ACCESS,FALSE,MESSAGE_IN_PROGRESS);
////	HANDLE	player2playermsgEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,P2P_MESSAGE_EVENT);
////	HANDLE	broadcastEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,BROADCAST_EVENT);
////	HANDLE	gameMsgEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,GAME_MSG_EVENT);
////	HANDLE	playerListRequest = OpenEvent(EVENT_ALL_ACCESS ,FALSE,MSG_LIST_EVENT);
////	HANDLE	winnerEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,WINNER_EVENT);
////	HANDLE	playerTossEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,PLAYER_TOSS_EVENT);
////
////	sscanf(msg,"%s",command);
////	printf("parseMessage recieved command %s to execute from player name %s\n",command,player->playerName);
////	if(WaitForSingleObject(msgInProgress,INFINITE) == WAIT_OBJECT_0)
////	{
////		if(!strcmp(command,"message"))
////		{
////
////			extractMsg(msg,userName,parsedMsg,PLAYER_TO_PLAYER_MESSAGE_E);
////			memcpy(player->playerMsgBox->p2pMsg.message,parsedMsg,strlen(parsedMsg)+1);
////			memcpy(player->playerMsgBox->p2pMsg.receiverName,userName,strlen(userName)+1);
////			memcpy(player->playerMsgBox->p2pMsg.senderName,player->playerName,strlen(userName)+1);
////			player->playerMsgBox->p2pMsg.senderNumber = player->playerNumber;
////			SetEvent(player2playermsgEvent);
////		}
////		else if(!strcmp(command,"broadcast"))
////		{
////			extractMsg(msg,userName,parsedMsg,BROADCAT_MESSAGE_E);
////			memcpy(player->playerMsgBox->bMsg.message,parsedMsg,strlen(parsedMsg)+1);
////			player->playerMsgBox->bMsg.playerSenderNumber = player->playerNumber;
////			SetEvent(broadcastEvent);
////		}
////		else if(!strcmp(command,"play"))
////		{
////			if(player->gameStarted)
////			{
////				if(player->playerTurn)
////				{
////					player->playerMsgBox->gMsg .drewRes = rand()%6 +1;
////					SetEvent(gameMsgEvent);
////				}
////			}
////		}
////		else if(!strcmp(command,"winner"))
////		{
////
////			player->playerMsgBox->winnerMsg.playerNumber = player->playerNumber;
////			memcpy(player->playerMsgBox->winnerMsg.winnerName,player->playerName,strlen(player->playerName)+1);
////			player->playerMsgBox->winnerMsg.winnerFound = TRUE;
////
////			sprintf(responeMsg,"Player %s won the game. Congratulations\n",player->playerName);
////			memcpy(player->playerMsgBox->winnerMsg.message,responeMsg,strlen(responeMsg)+1);
////			SetEvent(winnerEvent);
////		}
////		else if(!strcmp(command,"players"))
////		{
////			player->playerMsgBox->playerListMsg.requestingPlayerNumber = player->playerNumber;
////			player->playerMsgBox->playerListMsg.type = SINGLE_PLAYER_MESSAGE_E;
////			SetEvent(playerListRequest);
////		}
////		else if(!strcmp(command,"exit"))
////		{
////			player->playerMsgBox->errorMsg = TRUE;
////		}
////		else
////		{
////			printf("unknown command\n");
////		}
////
////		ReleaseMutex(msgInProgress);
////	}
////	else
////	{
////		printf("cant recieve mutex error :%d\n",GetLastError());
////		return;
////	}
////}
////
////void communicationThread (playersInformation *player)
////{
////	int iResult;
////	char recvMsg[MESSAGE_SIZE] = {0};
////	Sleep(10);
////
////	printf("Hello %s...we are ready to communicate\n",player->playerName);
////	do {
////
////		iResult = recv(player->playerSocket , recvMsg, MESSAGE_SIZE, 0);
////		printf("communicationThread recieved msg %s to execute from player name %s\n",recvMsg,player->playerName);
////
////
////		if ( iResult > 0 )
////		{
////			printf("player number %d recieved message:%s",player->playerNumber,recvMsg);
////			parseMessage(recvMsg,player);
////			memset(recvMsg,0,sizeof(recvMsg));//zero the buffer for next message
////		}
////		else if ( iResult == 0 )
////		{
////			printf("Connection closed %d \n",player->playerNumber);
////			player->playerMsgBox->errorMsg = TRUE;
////			ExitThread(OK);
////		}
////		else
////		{
////			printf("recv of player %d failed with error: %d\n",player->playerNumber, WSAGetLastError());
////			player->playerMsgBox->errorMsg = TRUE;
////			ExitThread(ERROR);
////		}
////
////	} while( iResult > 0 );
////}
////
////void waitForName(temporaryData	*tmpData)
////{
////	char playerName[MESSAGE_SIZE] = {0},playerNameFullCommand[MESSAGE_SIZE] = {0};	
////	HANDLE	playersUpdateLocker = OpenMutex (MUTEX_ALL_ACCESS,FALSE,PLAYER_UPDATE_LOCK);
////	char *token;
////	int recBytes;
////	Sleep(10);
////
////	do {
////		recBytes = recv(tmpData->tmpSocket,playerNameFullCommand,MESSAGE_SIZE,0);
////		if ( recBytes > 0 )
////		{
////			if(WaitForSingleObject( playersUpdateLocker, INFINITE ) == WAIT_OBJECT_0)
////			{
////				token = strtok(playerNameFullCommand,"=");
////				if(!strcmp(token,"username"))
////				{
////					token = strtok(NULL, "\n");
////					memcpy(tmpData->playerName,token,strlen(token)+1);
////					tmpData->isRegistered = TRUE;
////					ReleaseMutex (playersUpdateLocker);
////					ExitThread(OK);
////				}else
////				{
////					ReleaseMutex (playersUpdateLocker);
////					goto EXIT;
////				}
////			}
////		}
////		else if ( recBytes == 0 )
////		{
////			printf("Connection closed\n");
////			goto EXIT;
////		}
////		else
////			goto EXIT;
////
////	} while( recBytes > 0 );
////EXIT:
////	shutdown(tmpData->tmpSocket,SD_BOTH);
////	closesocket(tmpData->tmpSocket);
////	ExitThread(ERROR);
////}
////
////BOOL isExistingUserName(char *playerName, DataCollection *gameData,int numberOfPlayers)
////{
////	int i;
////	for(i = 1; i <= gameData->activePlayersNum ;i++)
////	{
////		if(!strcmp(playerName,gameData->playerInfo [i].playerName))
////			return TRUE;
////	}
////	return FALSE;
////}
////
////void sendWelcomeMsg(int numberOfPlayers,DataCollection *gameData )
////{
////	HANDLE  writeToLog = OpenMutex (MUTEX_ALL_ACCESS,FALSE,WRITE_PROTECT);
////	char newPlayerMsg[250]={0},AnnouncePlayer[250]={0};
////	int j;
////	for(j=1;j<=numberOfPlayers;j++)
////	{
////		gameData->gameMsgBox.newPlayerMsg.pawn=gameData->playerInfo[numberOfPlayers].playerPawn;
////		memcpy(gameData->gameMsgBox.newPlayerMsg.playerName,gameData->playerInfo[numberOfPlayers].playerName,strlen(gameData->playerInfo[numberOfPlayers].playerName)+1);
////		if(j == numberOfPlayers)//send message to the new latest player
////		{
////			gameData->gameMsgBox.newPlayerMsg.flag = TRUE;
////			sprintf(newPlayerMsg,"%s your game piece is %c\n",gameData->playerInfo[numberOfPlayers].playerName,gameData->playerInfo[numberOfPlayers].playerPawn);
////			send(gameData->playerInfo[numberOfPlayers].playerSocket,newPlayerMsg,strlen(newPlayerMsg)+1,0);
////		}
////		else
////		{
////			gameData->gameMsgBox.newPlayerMsg.flag = FALSE;
////			sprintf(AnnouncePlayer,"New player joined the game:%s %c\n",gameData->playerInfo[numberOfPlayers].playerName,gameData->playerInfo[numberOfPlayers].playerPawn);
////			send(gameData->playerInfo[j].playerSocket,AnnouncePlayer,strlen(AnnouncePlayer)+1,0);
////		}
////
////		gameData->gameMsgBox.messageTypeInProgress = NEW_PLAYER_MESSAGE;
////		writeToLogRoutine(gameData);
////	}
////}
////
////void UpdatePlayerData(DataCollection *gameData,int numberOfPlayers,int index)
////{
////	char pawnCharacters[MAXPLAYERSNUMBER+1] = {' ','@','#','%','*'};
////
////	gameData->playerInfo[numberOfPlayers].playerNumber = numberOfPlayers;
////	gameData->playerInfo[numberOfPlayers].playerPawn = pawnCharacters[numberOfPlayers];
////	memcpy(gameData->playerInfo[numberOfPlayers].playerName,gameData->tmpData[index].playerName,strlen(gameData->tmpData[index].playerName)+1 );
////	gameData->playerInfo[numberOfPlayers].playerSocket = gameData->tmpData[index].tmpSocket;//check if working
////	gameData->tmpData[index].activePlayer = TRUE;
////	gameData->activePlayersNum = numberOfPlayers;
////	gameData->playerInfo[numberOfPlayers].playerMsgBox = &gameData->gameMsgBox;
////}
////
////void playersManager(DataCollection *gameData)
////{
////	HANDLE	playersUpdateLocker = OpenMutex (MUTEX_ALL_ACCESS,FALSE,PLAYER_UPDATE_LOCK);
////	int numberOfPlayers =0;
////	DWORD waitRes;
////	int i;
////	Sleep(10);
////
////	printf("**********************************************************\n");
////	while(TRUE)
////	{
////		if(gameData->gameStarted)
////			ExitThread(OK);
////
////		for(i=0;i<10;i++)
////		{
////			if((gameData->tmpData[i].isRegistered) && (gameData->tmpData[i].activePlayer == FALSE))
////			{
////				waitRes = WaitForSingleObject(playersUpdateLocker,INFINITE);
////				CHECK_WAIT_FOR_OBJECT(waitRes);
////
////				if(isExistingUserName(gameData->tmpData[i].playerName,gameData,numberOfPlayers))
////				{
////					printf("user name alreasy exists\n");
////					send(gameData->tmpData[i].tmpSocket ,"Existing user name...exiting\n",strlen("Existing user name...exiting\n")+1,0);
////					shutdown(gameData->tmpData[i].tmpSocket,SD_BOTH);
////					closesocket(gameData->tmpData[i].tmpSocket);
////					gameData->tmpData[i].isRegistered = FALSE;
////					ReleaseMutex (playersUpdateLocker);
////					break;
////				}
////
////				numberOfPlayers++;
////				if(numberOfPlayers > MAXPLAYERSNUMBER)
////				{
////					shutdown(gameData->serverSocket,SD_RECEIVE);
////					closesocket(gameData->serverSocket);
////					for(i=0;i<10;i++)
////						if(!gameData->tmpData[i].activePlayer)
////						{
////							shutdown(gameData->tmpData[i].tmpSocket,SD_BOTH);
////							closesocket(gameData->tmpData[i].tmpSocket);
////						}
////						ReleaseMutex(playersUpdateLocker);
////						printf("exiting playersManager\n");
////						ExitThread(OK);
////				}
////				UpdatePlayerData(gameData,numberOfPlayers,i);
////
////				CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)communicationThread,&gameData->playerInfo[numberOfPlayers],0,&waitRes);
////
////				ReleaseMutex (playersUpdateLocker);
////				sendWelcomeMsg(numberOfPlayers,gameData);
////			}
////		}
////	}
////}
////
////int getPlayers(DataCollection *gameData)
////{
////	struct sockaddr_in client;
////	int client_len = sizeof(client);
////	HANDLE ThreadArray[10],playersManagerHandle;
////	DWORD WaitRes,threadID=0;
////	int index = 0 ;
////
////	Sleep(10);
////
////	playersManagerHandle = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)playersManager,gameData,0,&WaitRes);
////
////	while(TRUE)
////	{
////		if(index >= MAX_ECCEPT_INDEX )
////			index = MAX_ECCEPT_INDEX;
////
////		gameData->tmpData[index].tmpSocket = accept(gameData->serverSocket,(struct sockaddr*)&client,&client_len);
////		ThreadArray[index] = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)waitForName,&gameData->tmpData[index],0,&threadID);
////		index++;
////	}
////}
////
////void EventCreation(HANDLE *newEvent,LPCTSTR eventName)
////{
////	*newEvent = CreateEvent(NULL,TRUE,FALSE,eventName);  
////	if(NULL == *newEvent)
////	{	
////		printf("Error creating Event Error: %d\n", GetLastError());
////		exit(GetLastError());
////	}
////}
////
//void initiateThreads(HANDLE *threadsRoutinesArray,LPTHREAD_START_ROUTINE *threadRoutines,DataCollection *gameData)
//{
//	int i;
//	DWORD threadID = 0;
//
//	for(i=0;i<ROUTINE_NUMBER;i++)
//	{
//		threadsRoutinesArray[i] = CreateThread(NULL,0,threadRoutines[i],gameData,0,&threadID); 
//		CHECK_THREAD_CREATION(threadsRoutinesArray[i]);
//	}
//}
////
////void initiateServer(DataCollection* gameData,int portNumber )
////{
////	struct sockaddr_in server;
////	char *serverAddress = "127.0.0.1";
////	WSADATA wsaData;
////	int retval;
////
////	if ((retval = WSAStartup(0x202, &wsaData)) != 0)
////	{
////		printf("Server: WSAStartup() failed with error %d\n", retval);
////		WSACleanup();
////		exit(EXIT_ERROR);
////	}
////
////	server.sin_family = AF_INET;
////	server.sin_addr.s_addr = inet_addr(serverAddress);
////	server.sin_port = htons(portNumber);
////
////	gameData->serverSocket = socket(AF_INET,SOCK_STREAM,0);
////	if (gameData->serverSocket == INVALID_SOCKET)
////	{
////		printf("Server: socket() failed with error %d\n", WSAGetLastError());
////		WSACleanup();
////		exit(EXIT_ERROR);
////	}
////
////	if (bind(gameData->serverSocket, (struct sockaddr*)&server, sizeof(server)) == SOCKET_ERROR)
////	{
////		printf("Server: bind() failed with error %d\n", WSAGetLastError());
////		WSACleanup();
////		exit (EXIT_ERROR);
////	}
////
////	if (listen(gameData->serverSocket,MAXPLAYERSNUMBER) == SOCKET_ERROR)
////	{
////		fprintf(stderr,"Server: listen() failed with error %d\n", WSAGetLastError());
////		WSACleanup();
////		exit(EXIT_ERROR);
////	}
////	printf("Server: I'm listening and waiting connection on port %d\n",portNumber);
////}
////
////void resetAllTurns(DataCollection *gameData)
////{
////	int i;
////	for (i=1; i<= gameData->activePlayersNum;i++)
////		gameData->playerInfo[i].playerTurn = FALSE;
////	gameData->playerTurn = 0;
////}
////
////void sendGeneralMsgToPlayers(DataCollection *gameData)
////{
////	HANDLE	msgInProgress = OpenMutex(MUTEX_ALL_ACCESS,FALSE,MESSAGE_IN_PROGRESS);
////	int i;
////
////	Sleep(10);
////	printf("sendGeneralMsgToPlayers %d\n",GetLastError());
////	if(WaitForSingleObject(msgInProgress,INFINITE) == WAIT_OBJECT_0)
////	{
////		printf("			************** sendGeneralMsgToPlayers ****************			\n");
////
////		if(gameData->gameMsgBox.generalMsg.allPlayers)
////		{
////			for(i =0; i<gameData->activePlayersNum;i++)
////			{
////				send(gameData->playerInfo[i+1].playerSocket,gameData->gameMsgBox.generalMsg.message,strlen(gameData->gameMsgBox.generalMsg.message)+1,0);
////				gameData->gameMsgBox.generalMsg.receivers[i] = 0;
////			}
////		}
////		else
////		{
////			for(i =0; i<gameData->activePlayersNum;i++)
////			{
////				if(gameData->gameMsgBox.generalMsg.receivers[i])
////					send(gameData->playerInfo[i+1].playerSocket,gameData->gameMsgBox.generalMsg.message,strlen(gameData->gameMsgBox.generalMsg.message)+1,0);
////				gameData->gameMsgBox.generalMsg.receivers[i] = 0;
////			}
////
////		}
////
////		ReleaseMutex(msgInProgress);
////	}
////	else
////		printf("cant take mutex %d\n",GetLastError());
////}
////
////void createRandomGamePlayOrder(DataCollection *gameData,int *playerOrderArray)
////{
////	int i,randNumber,count = 0, activePlayersNum = gameData->activePlayersNum;
////	char gameMsgOrder[MESSAGE_SIZE];
////	BOOL flag = FALSE;
////	char playersList[MAXPLAYERSNUMBER][MESSAGE_SIZE]={{0}};
////
////	while(count != activePlayersNum)
////	{
////		randNumber = rand()%activePlayersNum +1;
////		flag = FALSE;
////		for(i=0; i<MAXPLAYERSNUMBER; i++)
////		{
////			if(playerOrderArray[i] == randNumber)
////			{
////				flag = TRUE;
////				break;
////			}
////		}
////		if(flag)
////			continue;
////		playerOrderArray[count] = randNumber;
////		count ++;
////	}
////
////	for(i=0; i < activePlayersNum ; i++)
////	{
////		if(i != activePlayersNum -1)
////			sprintf(playersList[i]," %s,",gameData->playerInfo[playerOrderArray[i]].playerName);
////		else
////			sprintf(playersList[i]," %s.",gameData->playerInfo[playerOrderArray[i]].playerName);
////		gameData->gameMsgBox.generalMsg.receivers[i] = 1;
////	}
////	sprintf(gameMsgOrder,"The order of the players' in the game is%s %s %s %s\n",playersList[0],playersList[1],playersList[2],playersList[3]);
////
////	memcpy(gameData->gameMsgBox.generalMsg.message,gameMsgOrder,strlen(gameMsgOrder)+1);
////	gameData->gameMsgBox.messageTypeInProgress = GAME_ORDER_MESSAGE;//write to log the players order
////	writeToLogRoutine(gameData);
////
////}
////
////void sendPlayerList(DataCollection *gameData)
////{
////	HANDLE	msgInProgress = OpenMutex(MUTEX_ALL_ACCESS,FALSE,MESSAGE_IN_PROGRESS);
////	HANDLE	playerListRequest = OpenEvent(EVENT_ALL_ACCESS ,FALSE,MSG_LIST_EVENT);
////
////	if(WaitForSingleObject(msgInProgress,INFINITE) == WAIT_OBJECT_0)
////	{
////		gameData->gameMsgBox.playerListMsg.type = BROADCAT_MESSAGE_E;//send the players list to all online players
////		SetEvent(playerListRequest);
////
////		gameData->gameMsgBox.messageTypeInProgress = PLAYER_LIST_MSG;
////		writeToLogRoutine(gameData);
////		ReleaseMutex(msgInProgress);
////	}
////	else
////		printf("cant send players list at game start\n");
////}
////
////void updateGameStarted(DataCollection *gameData)
////{
////	int i;
////
////	printf("***************game started*****************\n");
////	gameData->gameStarted = TRUE;
////	for(i=1;i<=gameData->activePlayersNum;i++)
////		gameData->playerInfo[i].gameStarted = TRUE;
////}
////
////void gameRoutine(DataCollection *gameData)
////{
////	HANDLE	playerTossEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,PLAYER_TOSS_EVENT);
////	HANDLE	gameMsgEvent = OpenEvent(EVENT_ALL_ACCESS ,FALSE,GAME_MSG_EVENT);
////	int playerOrderArray[MAXPLAYERSNUMBER]={0};
////	int i;
////	
////	updateGameStarted(gameData);
////	
////	createRandomGamePlayOrder(gameData,playerOrderArray);
////
////	sendPlayerList(gameData);
////
////	while(TRUE)
////	{
////		for(i = 0;i<gameData->activePlayersNum;i++)
////		{
////			resetAllTurns(gameData);
////			gameData->playerTurn = playerOrderArray[i];
////			gameData->playerInfo[playerOrderArray[i]].playerTurn = TRUE;
////			sendTurnMsg(gameData);
////			if((gameData->gameMsgBox.winnerMsg.winnerFound == TRUE) || (gameData->gameMsgBox.errorMsg))
////			{
////				ResetEvent(playerTossEvent);
////				goto EXIT_LOOP;
////			}
////
////			WaitForSingleObject(playerTossEvent,INFINITE);
////			ResetEvent(playerTossEvent);
////		}
////	}
////
////EXIT_LOOP: 
////	memcpy(gameData->gameMsgBox.generalMsg.message,"Game Finnished\n",strlen("Game Finnished\n")+1);
////	gameData->gameMsgBox.generalMsg.allPlayers = TRUE;
////	sendGeneralMsgToPlayers(gameData);
////
////	ForceExitAllPlayers(gameData);
////
////}
////
int serverRoutine(int portNumber,char* logFile){}
////{	
////	HANDLE	generalHandler;
////	HANDLE	startGameEvent;
////	HANDLE	player2playermsgEvent;
////	HANDLE	broadcastEvent; 
////	HANDLE	gameMsgEvent ;
////	HANDLE	playersUpdateLocker;
////	HANDLE	msgInProgress = 0;
////	HANDLE	playersListMsgEvent;
////	HANDLE  winnerEvent;
////	HANDLE	playerTossEvet;
////	HANDLE	threadsRoutinesArray[ROUTINE_NUMBER];
////	HANDLE	logWriteMutex;
////	DataCollection gameData ;
////	DWORD threadID = 0 ;
////	LPTHREAD_START_ROUTINE threadRoutines[] =
////	{ (LPTHREAD_START_ROUTINE)sendBroadcastMessage,(LPTHREAD_START_ROUTINE)playertoPlayerMessage,(LPTHREAD_START_ROUTINE)sendGameMessage,
////		(LPTHREAD_START_ROUTINE)sendPlayersListMessage,(LPTHREAD_START_ROUTINE)getPlayers,(LPTHREAD_START_ROUTINE)checkForWinnersRoutine};
////
////
////	ZeroMemory( &gameData, sizeof(gameData));
////	if(fopen_s(&gameData.logFile,logFile,"w") != 0)
////	{
////		erintf("cant open log file\n");
////		exit(0);
////	}
////
////	playersUpdateLocker = CreateMutex(NULL,FALSE,PLAYER_UPDATE_LOCK);
////	CHECK_MUTEX_CREATION(playersUpdateLocker);
////	msgInProgress = CreateMutex(NULL,FALSE,MESSAGE_IN_PROGRESS);
////	CHECK_MUTEX_CREATION(msgInProgress);
////	logWriteMutex = CreateMutex(NULL,FALSE,WRITE_PROTECT);
////	CHECK_MUTEX_CREATION(logWriteMutex);
////
////				/* INITIATE ALL EVENTS NEEDED */
////
////	EventCreation(&startGameEvent,GAME_START);
////	EventCreation(&player2playermsgEvent,P2P_MESSAGE_EVENT);
////	EventCreation(&broadcastEvent,BROADCAST_EVENT);
////	EventCreation(&gameMsgEvent,GAME_MSG_EVENT);
////	EventCreation(&playersListMsgEvent,MSG_LIST_EVENT);
////	EventCreation(&winnerEvent,WINNER_EVENT);
////	EventCreation(&playerTossEvet,PLAYER_TOSS_EVENT);
////	
////				/*	INITIATE THE SERVER*/
////
////	initiateServer(&gameData, portNumber);
////
////				/*INITIATE ROUTINES*/
////
////	initiateThreads(threadsRoutinesArray,threadRoutines,&gameData);
////
////
////	//Sleep(MINUTE);
////	Sleep(20000);
////	generalHandler = OpenMutex(0,TRUE,PLAYER_UPDATE_LOCK);
////
////	WaitForSingleObject(generalHandler,INFINITE);
////
////	if(!TerminateThread(threadsRoutinesArray[GET_PLAYERS_THREAD],threadID))
////		printf("can't terminate getPlayersThread \n");
////
////	
////	printf("the number of active players = %d \n",gameData.activePlayersNum);
////	if( 0 == gameData.activePlayersNum)
////	{
////		printf("No players connected, exiting...\n");
////		exit(0);
////	}
////
////
////	gameRoutine(&gameData);
////
////
////	CloseHandle(generalHandler);
////	CloseHandle(startGameEvent);
////	CloseHandle(player2playermsgEvent);
////	CloseHandle(broadcastEvent); 
////	CloseHandle(gameMsgEvent);
////	CloseHandle(playersUpdateLocker);
////	CloseHandle(msgInProgress);
////	CloseHandle(playersListMsgEvent);
////	CloseHandle(winnerEvent);
////	CloseHandle(playerTossEvet);
////	fclose(gameData.logFile);
////
////	return OK;
////}
