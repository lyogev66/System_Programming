#ifndef COMMON_H
#define COMMON_H
#include <stdio.h>
#include <string.h>
//#include <Windows.h>
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")

#define NO_WAIT						0
#define EXIT_ERROR			0
#define OK					1
#define MAX_BUFFER_SIZE		250
#define MESSAGE_SIZE		81
#define USERNAME_SIZE		31
#define GAME_ARRAY_SIZE		101
#define NUMBER_OF_PAWNS		4
#define DISPLAY_SIZE		7
#define SERVER_ADDRESS_STR "127.0.0.1"

typedef enum
{
	GAME_MESSAGE_E,
	BROADCAT_MESSAGE_E,
	PLAYER_TO_PLAYER_MESSAGE_E,
	SINGLE_PLAYER_MESSAGE_E,
	PLAYER_TURN_MSG,
	NEW_PLAYER_MESSAGE,
	GAME_ORDER_MESSAGE,
	PLAYER_LIST_MSG
}e_messageType;


#define CHECK_CONNECT_SOCKET(arg,port) {if(SOCKET_ERROR == arg)\
									{printf("Failed connecting to server on port %d\n", port);\
									printf("Error in connecting socket with Error: %x\n", WSAGetLastError());}\
									else {printf("Connected to server on port %d\n", port);}}
#define CHECK_CLOSE_SOCKET(arg) {if(SOCKET_ERROR == arg)\
										{printf("Error in closing socket with Error: %x\n", WSAGetLastError());			}}
#define CHECK_CREATE_SOCKET(arg) {if(INVALID_SOCKET == arg)\
										{printf("Error in creating socket with Error: %x\n", WSAGetLastError());			}}
#define CHECK_FILE_CREATION(arg) {if(0 != arg) \
										{ printf("File creation failed with %d\n",GetLastError()); exit(GetLastError());}}
#define CHECK_MUTEX_CREATION(arg) {	if (arg == NULL)\
										{ printf("CreateMutex error: %d\n", GetLastError());	 exit(GetLastError());	}\
											else {	if (GetLastError() == ERROR_ALREADY_EXISTS)\
														{printf("CreateMutex opened existing mutex\n");exit(GetLastError());} \
														else printf("CreateMutex created new mutex\n");	}}
#define CHECK_THREAD_CREATION(arg) { if(NULL == arg) \
										{ printf("Thread creation failed with %d\n ",GetLastError()); exit(GetLastError());}}

#define CHECK_WAIT_MULTIPLE(arg) {if((WAIT_OBJECT_0 != arg) && (WAIT_TIMEOUT != arg)) \
										{ printf("WaitForMutlipleObjets failed Error: %d\n", GetLastError());	 exit(GetLastError());	}}
#define CHECK_WAIT_FOR_SINGLE(arg) {if(WAIT_OBJECT_0 != arg)\
										{printf("Error in getting semaphore Error: %d\n", GetLastError());}}


#define CHECK_RELEASE(arg) {if(ERROR == arg)\
										{printf("Error in releasing mutex Error: %d\n", GetLastError());\
										if(ERROR == SetEvent(g_ErrorEvent))\
											printf("Failed to signal event Error %d\n",GetLastError()); \
										 ExitThread(ERROR_EXIT);}}

//#define CHECK_EVENT_CREATION(arg) {if(NULL == arg) \
//										{ printf("Error creating Event Error: %d\n", GetLastError());	 exit(GetLastError());	}}
#endif