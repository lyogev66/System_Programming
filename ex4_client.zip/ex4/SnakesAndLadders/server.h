#ifndef SERVER_H
#define SERVER_H

#include "common.h"
#include <tchar.h>

#define WIN32_LEAN_AND_MEAN

#define MAXPLAYERSNUMBER	4
#define MINUTE				60000
#define MESSAGE_SIZE		250
#define MESSAGETYPES		4
#define PLAYER_WITHOUT_NAME	33
#define	EXTRA_GAMER			11
#define	ROUTINE_NUMBER		6
#define MAX_ECCEPT_INDEX	9


#define BROADCAST_EVENT				_T("broadcastEvent")
#define P2P_MESSAGE_EVENT			_T("p2pMsgEvent")
#define GAME_MSG_EVENT				_T("gameMsgEvent")
#define	PLAYER_UPDATE_LOCK			_T("playersUpdateLock")
#define	GAME_START					_T("startGameEvent")
#define MESSAGE_IN_PROGRESS			_T("messageInProgress")
#define MSG_LIST_EVENT				_T("playersListMsgEvent")
#define	WINNER_EVENT				_T("weHaveAWinner")
#define	PLAYER_TOSS_EVENT			_T("playerTossEvent")
#define	WRITE_PROTECT				_T("writingToLogFile")


typedef enum
{
	ERROR_ECCURED,
	WINNER_FOUND
}e_exit_reason;

typedef struct
{
	char message[MESSAGE_SIZE];
	int receivers[MAXPLAYERSNUMBER];
	BOOL allPlayers;
}generalMsgToPlayers;

typedef struct
{
	char pawn;
	char playerName[MESSAGE_SIZE];
	BOOL flag;
}newPlayerMesage;

typedef struct
{
	e_messageType type;
	int requestingPlayerNumber;
	char message[MESSAGE_SIZE];
}playersListMessage;

typedef struct
{
	char message[MESSAGE_SIZE];
	int playerNumberTurn;
	int drewRes;
}gameMessage;


typedef struct
{
	char message[MESSAGE_SIZE];
	int playerSenderNumber;
}broadcastMessage;

typedef struct
{
	char message[MESSAGE_SIZE];
	char senderName[MESSAGE_SIZE];
	char receiverName[MESSAGE_SIZE];
	int senderNumber;
}playerToPlayerMessage;

typedef struct
{
	int playerNumber;
	char winnerName[MESSAGE_SIZE];
	char message[MESSAGE_SIZE];
	volatile BOOL winnerFound;

}winnerMessage;
typedef struct
{
	int playerTurn;
	char playerName[MESSAGE_SIZE];
	char msgToCurrentPlayer[MESSAGE_SIZE];
	char msgToOtherPlayers[MESSAGE_SIZE];
	BOOL flag;
}playerTurnToPlayMsg;
typedef struct
{
	playerTurnToPlayMsg pttpMsg;
	generalMsgToPlayers	generalMsg;
	winnerMessage winnerMsg;
	playersListMessage playerListMsg;
	gameMessage gMsg;
	broadcastMessage bMsg;
	playerToPlayerMessage p2pMsg;
	BOOL errorMsg;
	e_messageType messageTypeInProgress;
	newPlayerMesage newPlayerMsg;
}messageBox;

typedef struct
{
	char 				playerName[31];
	char				playerPawn;
	SOCKET				playerSocket;
	messageBox			*playerMsgBox;
	int					playerNumber;
	BOOL				playerTurn;
	BOOL				gameStarted;
}playersInformation;


typedef struct
{
	SOCKET	tmpSocket;
	char	playerName[30];
	BOOL	isRegistered;
	BOOL	activePlayer;
}temporaryData;

typedef struct
{
	playersInformation	playerInfo[MAXPLAYERSNUMBER+1];
	SOCKET				serverSocket;
	int					activePlayersNum;
	int					playerTurn;
	messageBox			gameMsgBox;
	temporaryData		tmpData[10];
	BOOL				gameStarted;
	FILE				*logFile;
}DataCollection;

typedef enum
{
	BROADCAST_THREAD_E,
	P2P_THREAD,
	GAME_MSG_THREAD_E,
	PLAYER_LIST_THREAD_E,
	EXIT_THREAD_E,
	GET_PLAYERS_THREAD,
	SEARCH_WINNER_THREAD,
	LAST_THREAD
}THREADS_ID_E;

int serverRoutine(int portNumber,char* logFile);

#endif
