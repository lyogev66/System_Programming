README.txt 
The file extension of the test file is ".txt"
The test file size is 5.00B
The file was created on 04/12/2016, 18:14:00
The file was last modified on 07/12/2016, 18:07:56
The file's first 5 bytes are:hello
