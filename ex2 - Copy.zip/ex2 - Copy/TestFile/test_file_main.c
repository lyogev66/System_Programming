#include <stdio.h>//for FILE object

#include <windows.h> //for thread and Sleep

int  main(int argc ,char * argv[])
{
	Sleep(1000);
	printf("Process finnished \n");
	return 0;
}


