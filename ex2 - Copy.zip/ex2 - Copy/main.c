#include "TestManager.h"

void CreateProcessSimpleMain();
BOOL InitiateProcess(LPTSTR CommandLine, PROCESS_INFORMATION *ProcessInfoPtr);

void pad_argument(char *str)
{
	int length;
	char *padded_str =NULL;

	length = strlen(str);

	padded_str = (char*) calloc(length+3*CHARACTER_SIZE,CHARACTER_SIZE);
	if(padded_str ==  NULL)
		exit(0);

	strcat(padded_str," ");
	strcat(padded_str,str);

	str = (char*)realloc(str,strlen(padded_str) +1);
	if(str ==NULL)
	{
		printf("reallocating str failed\n");
		exit(0);
	}

	memset(str,0,strlen(padded_str));
	strcpy(str,padded_str);
	free(padded_str);
}

char* Create_Process_Argument(char *target_process_name,char *file_name,char *output_directory_name)
{
	char* ret =NULL ,*argument_command=NULL;


	argument_command = (char*) calloc(strlen(output_directory_name)+ strlen(file_name)+ strlen(target_process_name) + CHARACTER_SIZE,CHARACTER_SIZE);
	if(argument_command == NULL)
	{
		printf("ERROR at argument_command \n");
		exit(0);
	}
	ret = strcat(argument_command,target_process_name);
	if (ret == NULL)
		goto FAIL;
	ret =strcat(argument_command,file_name);
	if (ret == NULL)
		goto FAIL;
	ret = strcat(argument_command,output_directory_name);
	if (ret == NULL)
		goto FAIL;
	return argument_command;

FAIL:
	printf("Create_Process_Argument failed\n");
	exit(0);
}

char* create_output_folder_path(char *path,int flag)
{
	char* tmp=NULL, *ret=NULL;
	if(!flag)
	{
		tmp = (char*) calloc (strlen(path)+ /*strlen("runtime_logfile.txt")*/ + 3,CHARACTER_SIZE);
		if(tmp == NULL)
			exit(ERROR_CODE);
		strcat(tmp,"./");
		strcat(tmp,path);
		return tmp;
	}
	else
	{
		tmp = (char*) calloc (strlen(path)+ strlen("runtime_logfile.txt") + 4,CHARACTER_SIZE);
		strcat(tmp,"./");
		strcat(tmp,path);
		strcat(tmp,"/");
		strcat(tmp,"runtime_logfile.txt");
	}
	return tmp;
}

Process_list *g_Live_process_head = NULL, *g_Dead_process_head=NULL;



void process_lists_management()
{
	Process_list *live_tmp = g_Live_process_head , *dead_tmp = g_Dead_process_head, *tmp=NULL;
	DWORD	exitcode;
	while(live_tmp != NULL)
	{
		GetExitCodeProcess(live_tmp->procinfo.hProcess,&exitcode);
		if( exitcode == STILL_ACTIVE)
			live_tmp = live_tmp->next;
		else
		{
			tmp = pop_node_from_list(g_Live_process_head,live_tmp->procinfo.dwProcessId)
			g_Dead_process_head = push_element(g_Dead_process_head,tmp);
		}
		live_tmp = live_tmp->next;
	}

}







int main(int argc,char* argv[])
{
	char ch ,BOOL= TRUE;
	FILE *instream, *outstream;
	char *file_name = NULL,*output_directory_name = NULL,target_process_name[] =TARGET_NAME,*complete_arguments_command =NULL,*output_dir =NULL;
	int length=0;
	int loop =5;
	

	output_directory_name = (char*) malloc(strlen(argv[2]) + CHARACTER_SIZE);
	if(output_directory_name == NULL)
		exit(0);
	strcpy(output_directory_name,argv[2]);


	output_dir = create_output_folder_path(argv[2],CREATE_DIRECTORY_FLAG);
	
	RemoveDirectory(output_dir);
	if(!CreateDirectory(output_dir,NULL))
	{
		printf("%s %s \n",argv[2], GetLastError()==ERROR_ALREADY_EXISTS? "ERROR_ALREADY_EXISTS":"ERROR_PATH_NOT_FOUND");
		exit(0);
	}

	output_dir = create_output_folder_path(argv[2],CREATE_FILE_INSIDE_DIRECTORY_PATH);
	if(fopen_s(&outstream,output_dir,"w+")!= OK)
		exit(0);

	if(fopen_s(&instream,argv[1],"r+") != OK)
		exit(0);

	pad_argument(output_directory_name);


	file_name = (char*)calloc(CHARACTER_SIZE,CHARACTER_SIZE);
	if(NULL==file_name)
	{
		printf("Error allocating string for file name \n");
		exit(ERROR_CODE);
	}
	ch = getc(instream);
	while (1)
	{
		if ((ch != '\r') && (ch!='\n') && (ch !='\0') && (ch!=EOF))
		{
			length++;
			file_name = (char*)realloc(file_name, length + CHARACTER_SIZE);
			if(NULL == file_name)
			{
				printf("Error parsing file name \n");
				exit(ERROR_CODE);
			}
			file_name[length - CHARACTER_SIZE] = ch;
		}
		else
		{
			file_name[length] = '\0';

			pad_argument(file_name);

			complete_arguments_command = Create_Process_Argument(target_process_name,file_name,output_directory_name);
			InitiateProcess(complete_arguments_command,outstream,file_name);

			//printf("%s \n", complete_arguments_command);

			length = 0;
			if(EOF == ch)
			{
				BOOL = FALSE;
				break;
			}
		}
		ch = getc(instream);

	}

	while(g_Live_process_head !=NULL)
	{
		process_lists_management();
		fprintf(outstream,"List of running processes:\n");
		print_live_process_list(g_Live_process_head,outstream);

		fprintf(outstream,"List of finished processes:\n");
		print_dead_process_list(g_Dead_process_head,outstream);

		loop --;
		Sleep(100);
	

	}


//EXIT_LOOP:
	printf("Exiting\n");


	free(complete_arguments_command);
	free(file_name);
	fclose(instream);
	fclose(outstream);
	free(output_dir);


}


BOOL InitiateProcess(LPTSTR CommandLine,FILE *fp,char* file_name)
{
	PROCESS_INFORMATION *procinfo = NULL;
	STARTUPINFO	*startinfo= NULL;
	Process_list *node = NULL;
	procinfo = (PROCESS_INFORMATION*) calloc(SINGLE_OBJECT,sizeof(PROCESS_INFORMATION));
	startinfo = (STARTUPINFO*) calloc(SINGLE_OBJECT,sizeof(STARTUPINFO));
	startinfo ->cb= sizeof(STARTUPINFO);
	startinfo->cbReserved2= NULL;
	startinfo->dwFillAttribute = 0;


	if(CreateProcess(NULL,			/*  No module name (use command line). */
			CommandLine,			/*  Command line. */
			NULL,					/*  Process handle not inheritable. */
			NULL,					/*  Thread handle not inheritable. */
			FALSE,					/*  Set handle inheritance to FALSE. */
			NORMAL_PRIORITY_CLASS,	/*  creation/priority flags. */
			NULL,					/*  Use parent's environment block. */
			NULL,					/*  Use parent's starting directory. */
			startinfo,				/*  Pointer to STARTUPINFO structure. */
			procinfo				/*  Pointer to PROCESS_INFORMATION structure. */
		))
	{
		fprintf(fp,"Successfully created a process with ID %d to execute %s\n",procinfo->dwProcessId,file_name);
		node = creat_node(*procinfo,*startinfo,file_name);
		g_Live_process_head = push_element(g_Live_process_head,node);

		WaitForSingleObject(procinfo.hProcess,INFINITE); /* Waiting 5 secs for the process to end */
	}
	else
		fprintf(fp,"!!! Failed to create new process to run %s. Error code: %d \n !!!",CommandLine,GetLastError());
}